# Web application SPA

This is a React web application SPA.

## Setup notes

Tested with **Node v6.9.1** and **NPM 3.10.8.**

Setup the project locally by running ```npm install```.

Afterwards, run ```npm run hook-add``` to add prepush linter validation.

Run the dev build locally by running ```npm start```

To build for prod, run ```npm run build```.

If you want to see the website in release mode, built for production, run ```npm run preview```.

You can run the linter manually by running ```npm run lint```.

# Client facing:

PREVIEW - http://localhost:47825/

import 'es6-promise';
import 'whatwg-fetch';

function getAboutLifemilesAsync(country, language, currency) {
  const url = `${ endpoints['aboutYou'] }/${ language }/${ country }/${ currency }`;

  return fetch( url)
    .then((response) => {
      return response;
    });
}

export default {
  getAboutLifemilesAsync,
};

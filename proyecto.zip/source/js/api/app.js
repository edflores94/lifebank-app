import 'es6-promise';
import 'whatwg-fetch';

function getMenuCountries(request){
  const url = `${endpoints['menuCountries']}`;

  return fetch(url, request)
    .then((response) => {
      return response.json();
    })
}

export default {
  getMenuCountries
};
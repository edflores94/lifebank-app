import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';

@connect(state => ({
  initialLoading: state.app.get('initialLoading')
}))
export default class App extends Component {
  static propTypes = {
    initialLoading: PropTypes.bool
  }

  constructor(props) {
    super(props);
  }

  componentWillMount() {
   
  }

  render() {
    debugger;
    const {
      children
    } = this.props;

    return (
      <div>
        <div className={ styles.container }>
          <div>
            { children }
          </div>
        </div>
      </div>  
    );
  }
}
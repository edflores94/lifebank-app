import React, { Component } from 'react';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import { Link } from 'react-router';
import classNames from 'classnames';
import literals from 'common/literals';
import { getAboutLifemilesAsync } from 'actions/about';
import { routeCodes } from '../../common/routeConfig';
import styles from './AboutLifemiles.scss';
import CookiesConfiguration from 'functions/CookiesConfiguration';
import { browserHistory } from 'react-router';

@connect(state => ({
  about: state.about.get('about'),
}))

export default class AboutLifemiles extends Component {
  static propTypes = {
    about: PropTypes.object,
  }
  constructor(props) {
    super(props);
    this.state = {
      
    }

  }
  

  render() {
    return <div>HOLAAAA</div>;
  }
}

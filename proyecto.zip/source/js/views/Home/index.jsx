import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { browserHistory } from 'react-router';
import classNames from 'classnames';
import Menu from '../../components/Menu/Menu';
import Loader from '../../components/Loader/Loader';
import { routeCodes } from '../../common/routeConfig';
import CookiesConfiguration from '../../functions/CookiesConfiguration';

//@TrackBreakpoint
@connect(state => ({
  asyncLoading: state.fly.get('asyncLoading'),
  breakpoint: state.app.get('breakpoint')
}))
export default class Fly extends Component {
  static propTypes = {
    dispatch: PropTypes.func,
    asyncLoading: PropTypes.bool,
    router: PropTypes.object,
    breakpoint: PropTypes.string,
  }

  constructor(props) {
    super(props);
  }

  render() {
    const { asyncLoading } = this.props;   
    
    const style = {
      display: asyncLoading ? 'none' : 'block',
    };

    const menuBackgroundColor = '#CB1313';

    return (
      <div>
        <h1>Hello world!</h1>
        <Menu background={ menuBackgroundColor } />
      </div>
    );
  }
}

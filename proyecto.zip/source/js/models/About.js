/**
 * Model for the about lifemiles.
 */
const AboutLifemilesModel = {
  header: {
    type: 'object',
    optional: false,
    properties: {
      title: {
        type: 'string',
        optional: false,
      },
      text: {
        type: 'string',
        optional: false,
      },
      backgroundImage: {
        type: 'string',
        optional: false,
      },
      image: {
        type: 'object',
        optional: false,
        properties: {
          title: {
            type: 'string',
            optional: false,
          },
          url: {
            type: 'string',
            optional: false,
          },
        },
      },
    },
  },
  aboutLMItems: {
    type: 'object',
    optional: false,
    isArray: true,
    item: {
      type: 'object',
      optional: false,
      properties: {
        title: {
          type: 'string',
          optional: false,
        },
        text: {
          type: 'string',
          optional: false,
        },
        linkTo: {
          type: 'string',
          optional: false,
        },
        image: {
          type: 'object',
          optional: false,
          properties: {
            title: {
              type: 'string',
              optional: false,
            },
            url: {
              type: 'string',
              optional: false,
            },
          },
        },
      },
    },
  },
};

export default AboutLifemilesModel;

import { routeCodes } from '../../common/routeConfig';
import  literals  from '../../common/literals';

export const loggedOutItems = {
  join: {
    label: { en: 'Join', es: 'Únete' },
    route: routeCodes.ENROLLMENT,
  },
};

export const indexedRoutes = [
  'account',
  'fly',
  'shop',
  'stay',
  'drive',
  'miles',
  'credit-card',
  'deals',
  'eat'
];

export const menuItems =  literals.menus.MENU_ITEMS;
export const menuItems2 =  literals.menus.MENU_ITEMS2;
export const menuMore = { en: 'More', es: 'Más'};

export const menuItemsConfig = [
  {
    route: routeCodes.ACCOUNT_OVERVIEW_DEFAULT,
    subItems: [
      { label: { en: 'Overview', es: 'Resumen' }, route: routeCodes.ACCOUNT_OVERVIEW_DEFAULT },
      { label: { en: 'Activity', es: 'Actividad' }, route: routeCodes.ACCOUNT_ACTIVITY },
      { label: { en: 'Profile', es: 'Perfil' }, route: routeCodes.ACCOUNT_PROFILE },
      { label: { en: 'Avianca Elite Status', es: 'Estatus Élite Avianca' }, route: routeCodes.ACCOUNT_ELITE },
      // { label: { en: 'Trips', es: 'Viajes' }, route: routeCodes.ACCOUNT_TRIPS },
      //{ label: { en: 'Favorites', es: 'Favoritos' }, route: routeCodes.ACCOUNT_FAVORITES },
    ],
  },
  {
    route: routeCodes.FLY_FIND,
    subItems: [
      { label: { en: 'Book flights', es: 'Buscar vuelos' }, route: routeCodes.FLY_FIND },
      { label: { en: 'Flight partners', es: 'Aliados aéreos' }, route: routeCodes.FLY_PARTNERS },
      { label: { en: 'Missing Miles', es: 'Millas pendientes' }, route: routeCodes.FLY_RETRO },
      { label: { en: 'Upgrades', es: 'Ascensos' }, route: routeCodes.FLY_UPGRADES },
      { label: { en: 'Baggage', es: 'Equipaje' }, route: routeCodes.FLY_BAGGAGE },
      { label: { en: 'VIP Lounges', es: 'Salas VIP' }, route: routeCodes.FLY_VIP_LOUNGES },
      { label: { en: 'Avianca Elite Program', es: 'Programa Élite de Avianca' }, route: routeCodes.FLY_AVIANCA_ELITE_PROGRAM }
    ],
  },
  {
    route: routeCodes.SHOPPING_PARTNERS,
    subItems: [
      { label: { en: 'Shopping partners', es: 'Comercios aliados' }, route: routeCodes.SHOPPING_PARTNERS },
      { label: { en: 'Online Shopping', es: 'Online Shopping' }, route: routeCodes.SHOPPING_PARTNERS_IGUAMA },
      { label: { en: 'Lifemiles catalog', es: 'Catálogo Lifemiles' }, route: routeCodes.LM_CATALOG }, 
    ],
  },
  {
    route: routeCodes.STAY_HOTELS,
    subItems: [
      { label: { en: 'Book hotels', es: 'Buscar hoteles' }, route: routeCodes.STAY_HOTELS },
      { label: { en: 'Hotel partners', es: 'Hoteles aliados' }, route: routeCodes.STAY_HOTEL_PARTNERS },
      { label: { en: 'LM Experiences', es: 'LM Experiences' }, route: routeCodes.STAY_THINGS_TO_DO },
    ],
  },
  { route: routeCodes.DRIVE, subItems: null },
  {
    route: routeCodes.MILES_LANDING,
    subItems: null,
  },
  {
    route: routeCodes.CREDIT_GET_CARD,
    subItems: [
      { label: { en: 'Get a credit card', es: 'Obtén una tarjeta de crédito' }, route: routeCodes.CREDIT_GET_CARD },
      { label: { en: 'Convert your points', es: 'Convierte tus puntos' }, route: routeCodes.CREDIT_CONVERT_POINT },
    ],
  },
  { route: routeCodes.DEALS_ALL_DEALS,
    subItems: [
      { label: { en: 'Your deals', es: 'Tus ofertas' }, route: routeCodes.DEALS_YOUR_DEALS },
      { label: { en: 'All deals', es: 'Todas las ofertas' }, route: routeCodes.DEALS_ALL_DEALS },
      { label: { en: 'Search', es: 'Buscar' }, route: routeCodes.DEALS_SEARCH_FOR_DEALS },
    ],
  },
  { route: routeCodes.EAT, subItems: null },
  { route: '/404', subItems: null },
];



export const menuItemsConfig2 = [
  {
    route: routeCodes.ACCOUNT_OVERVIEW_DEFAULT,
    subItems: [
      { label: { en: 'Overview', es: 'Resumen' }, route: routeCodes.ACCOUNT_OVERVIEW_DEFAULT },
      { label: { en: 'Activity', es: 'Actividad' }, route: routeCodes.ACCOUNT_ACTIVITY },
      { label: { en: 'Profile', es: 'Perfil' }, route: routeCodes.ACCOUNT_PROFILE },
      { label: { en: 'Avianca Elite Status', es: 'Estatus Élite Avianca' }, route: routeCodes.ACCOUNT_ELITE },
     // { label: { en: 'Trips', es: 'Viajes' }, route: routeCodes.ACCOUNT_TRIPS },
      //{ label: { en: 'Favorites', es: 'Favoritos' }, route: routeCodes.ACCOUNT_FAVORITES },
    ],
  },
  {
    route: routeCodes.FLY_FIND,
    subItems: [
      { label: { en: 'Find flight', es: 'Buscar vuelos' }, route: routeCodes.FLY_FIND },
      { label: { en: 'Flight partners', es: 'Aliados aéreos' }, route: routeCodes.FLY_PARTNERS },
      { label: { en: 'Pending miles', es: 'Millas pendientes' }, route: routeCodes.FLY_RETRO },
      { label: { en: 'Upgrades', es: 'Ascensos' }, route: routeCodes.FLY_UPGRADES },
      { label: { en: 'Baggage', es: 'Equipaje' }, route: routeCodes.FLY_BAGGAGE },
      { label: { en: 'VIP Lounges', es: 'Salas VIP' }, route: routeCodes.FLY_VIP_LOUNGES },
      { label: { en: 'Avianca Elite Program', es: 'Programa Élite de Avianca' }, route: routeCodes.FLY_AVIANCA_ELITE_PROGRAM },
    ],
  },
  {
    route: routeCodes.SHOPPING_PARTNERS,
    subItems: [
      { label: { en: 'Shopping partners', es: 'Comercios aliados' }, route: routeCodes.SHOPPING_PARTNERS },
      { label: { en: 'Online Shopping', es: 'Online Shopping' }, route: routeCodes.SHOPPING_PARTNERS_IGUAMA },
      { label: { en: 'Lifemiles catalog', es: 'Catálogo Lifemiles' }, route: routeCodes.LM_CATALOG },
    ],
  },
  {
    route: routeCodes.STAY_HOTELS,
    subItems: [
      { label: { en: 'Hotels', es: 'Hoteles' }, route: routeCodes.STAY_HOTELS },
      { label: { en: 'Hotel Partners', es: 'Hoteles aliados' }, route: routeCodes.STAY_HOTEL_PARTNERS },
      { label: { en: 'Things To Do', es: 'Things to do' }, route: routeCodes.STAY_THINGS_TO_DO },
    ],
  },
  {
    route: routeCodes.MILES_LANDING,
    subItems: null,
  },
  { route: routeCodes.DRIVE, subItems: null },
  {
    route: routeCodes.CREDIT_GET_CARD,
    subItems: [
      { label: { en: 'Get a credit card', es: 'Obtén una tarjeta de crédito' }, route: routeCodes.CREDIT_GET_CARD },
      { label: { en: 'Convert your points', es: 'Convierte tus puntos' }, route: routeCodes.CREDIT_CONVERT_POINT },
    ],
  },
  { route: routeCodes.DEALS_ALL_DEALS,
    subItems: [
      { label: { en: 'Your deals', es: 'Tus ofertas' }, route: routeCodes.DEALS_YOUR_DEALS },
      { label: { en: 'All deals', es: 'Todas las ofertas' }, route: routeCodes.DEALS_ALL_DEALS },
      { label: { en: 'Search', es: 'Buscar' }, route: routeCodes.DEALS_SEARCH_FOR_DEALS },
    ],
  },
  { route: routeCodes.EAT, subItems: null },
  { route: '/404', subItems: null },
];
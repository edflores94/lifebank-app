import React, { Component } from 'react';
import { IndexLink, Link } from 'react-router';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import { LANGUAGE_EN, LANGUAGE_ES } from 'common/constants';
import { getOAuth2Object, numberWithCommas } from 'common/util';
import literals from 'common/literals';

import cx from 'classnames';
import bowser from 'bowser';
import { routeCodes } from '../../common/routeConfig';
import { indexedRoutes, menuItems,menuItems2, menuItemsConfig,menuItemsConfig2, loggedOutItems, menuMore } from './MenuModel';
import styles from './Menu.scss';
import logoUrl from '../../../../public/images/bank-logo.png';
import darkLogoUrl from '../../../../public/images/bank-logo';
import { capitalizeFirstLetter } from 'common/util';


const DEFAULT_LIMIT_HEIGHT = 70; // same as $header-height in Menu.scss
const VISIBLE_MENU_ITEMS = 5;


@connect(state => ({
  language: state.app.get('language')
}))
export default class Menu extends Component {

  static propTypes = {
    fullHeight: PropTypes.bool
  }

  constructor(props) {
    super(props);

    this.menuItemClass = {
      [LANGUAGE_EN]: styles.menuItem,
      [LANGUAGE_ES]: styles.menuItemES,
    };
    
  }

  handleLinkClick(index) {
    const { user } = this.props;    
    let menuName = user && user.data ? (user.data.displayName ? user.data.displayName : user.data.firstName) : '';
    
    const itemsConf = menuName && menuName.length > 9 ? menuItemsConfig2 : menuItemsConfig;

    this.setState({
      selectedItemIndex: index,
      subItems: itemsConf[index].subItems,
    });
    window.scrollTo(0, 0);
    const htmlHasNoScrollableClass = document.querySelector('html').classList.contains('noScrollable');
    if (htmlHasNoScrollableClass) {
      document.querySelector('html').className = '';
    }
  }

  openProfileTooltip() {
    this.setState({
      showProfileTooltip: true,
    });
  }

  closeProfileTooltip() {
    this.setState({
      showProfileTooltip: false,
    });
  }

  openLocalizationTooltip() {
    this.setState({
      showLocalizationTooltip: true,
    });
  }

  closeLocalizationTooltip() {
    this.setState({
      showLocalizationTooltip: false,
    });
  }

  

  handleCountryClick(obj) {
    const { dispatch } = this.props;
    
    if (obj.key !== obj.countryName) {
      dispatch(setCountry(obj.key.iso2));
    }
    this.handleModalClose();
  }

  renderPrimaryMenu() {
    const { showFullMenu, selectedItemIndex } = this.state;
    const { language, noFixed, onlyHeaderNav, flyBookerLoader } = this.props;

    const performTransition = showFullMenu && selectedItemIndex < VISIBLE_MENU_ITEMS;

    const menuItemsWrapperClasses = cx(
      styles.menuItemsWrapper,
      'side-padding',
      { [styles.noFixed]: noFixed },
      { [styles.menuTransition]: performTransition },
      { [styles.hidden]: onlyHeaderNav },
      { [styles.menuItemsWrapperHidden]: flyBookerLoader }
    );

    const menuButtonClasses = cx(
      styles.button,
      this.menuItemClass[language],
      styles.moreButton
    );

    const showDotsmenuButtonClasses = cx(
      styles.button,
      this.menuItemClass[language],
      styles.moreButton,
      styles.showDotsmoreButton
    );

    const showDots = this.props.user && this.props.user.navigationDots;

    return showDots ? (
      <div
        className={ menuItemsWrapperClasses }
        id='menuItemsWrapper'
      >
        { this.renderPrimaryMenuItems() }
        {
          !showFullMenu &&
          <button
            onClick={ this.handleMenuExtension }
            className={ menuButtonClasses }
          >
            <span>{ menuMore[language] }</span>
          </button>
        }
      </div>
    ) :
      <div
        className={ menuItemsWrapperClasses }
        id='menuItemsWrapper'
      >
        { this.renderPrimaryMenuItems() }
        {
          !showFullMenu &&
          <button
            onClick={ this.handleMenuExtension }
            className={ showDotsmenuButtonClasses }
            data-content= { menuMore[language] }
          >
            <span>{ menuMore[language] }</span>
          </button>
        }
      </div>;
  }

  renderIndexLink() {
    const { user, signedIn, language } = this.props;
    const { showFullMenu } = this.state;    
    let menuName = user && user.data ? (user.data.displayName ? user.data.displayName : user.data.firstName) : '';
    const itemsConf = menuName && menuName.length > 9 ? menuItemsConfig2 : menuItemsConfig;

    
    const indexLinkClasses = cx(
      this.menuItemClass[language],
      { [styles.extended]: showFullMenu }
    );

    /*if(menuName.length > 9){
      menuName = menuName//`${menuName.substring(0,6)}...`;
    }*/

    return signedIn && user && user.data ?
      <IndexLink
        key={ 0 }
        className={ indexLinkClasses }
        to={ itemsConf[0].route }
        onClick={ () => { this.handleLinkClick(0); } }
      >
        { capitalizeFirstLetter(menuName) }
      </IndexLink> :
      <IndexLink
        key={ 0 }
        className={ indexLinkClasses }
        to={ loggedOutItems.join.route }
      >
        { loggedOutItems.join.label[language] }
      </IndexLink>;
  }

  renderLink(item, index) {
    const { language, user } = this.props;
    const { showFullMenu, menuItemsLoading } = this.state;  
    let menuName = user && user.data ? (user.data.displayName ? user.data.displayName : user.data.firstName) : '';
    const itemsConf = menuName && menuName.length > 9 ? menuItemsConfig2 : menuItemsConfig;

    const menuItemClasses = cx(
      this.menuItemClass[language],
      { [styles.menuItemsLoadTransition]: menuItemsLoading },
      { [styles.extended]: showFullMenu }
    );

    return (
      <Link
        key={ index }
        className={ menuItemClasses }
        to={ itemsConf[index].route }
        onClick={ () => { this.handleLinkClick(index); } }
      >
        { item }
      </Link>
    );
  }

  renderPrimaryMenuItems() {
    const { language, user } = this.props;
    const { showFullMenu } = this.state;

    const itemsNumber = menuItems[language].length;
    let menuName = user && user.data ? (user.data.displayName ? user.data.displayName : user.data.firstName) : '';
    const visibleItemsNumber = (showFullMenu) ? itemsNumber :( menuName.length > 9 ? VISIBLE_MENU_ITEMS - 1 : VISIBLE_MENU_ITEMS );
    let itemsToMenu = menuName && menuName.length > 9 ? menuItems2 : menuItems;

    return itemsToMenu[language].map((item, index) => {
      if (index > visibleItemsNumber) return null;
      return (index === 0) ?
        this.renderIndexLink() :
        this.renderLink(item, index);
    });
  }

  renderSubMenu() {
    const { isFirstTime, flyBookerLoader } = this.props;

    const subMenuClasses = cx(
      styles.subMenu,
      'side-padding',
      { [styles.noOpacity]: isFirstTime },
      { [styles.menuItemsWrapperHidden]: flyBookerLoader }
    );

    const currentRoute = location.pathname.split('/')[2];

    switch (currentRoute) {
      default: return (
        <div className={ subMenuClasses }>
          { this.renderSubItems() }
        </div>
      );
    }
  }

  renderSubItems() {
    const { country, language } = this.props;
    const { subItems } = this.state;

    const initIndex = indexedRoutes.indexOf(location.pathname.split('/')[1]);
    if (initIndex === 2) { // shop
      return subItems.map((subItem, index) => {
        switch(index){
          case 0: //shopping partners
            return (
              <Link
                key={ index }
                activeClassName={ cx(styles.subItem, styles.active) }
                className={ styles.subItem }
                to={ subItem.route }
              >
                { subItem.label[language] }
              </Link>
            );
          break;
          case 1: //iguama
          if( country.toUpperCase() === 'US' || country.toUpperCase() === 'EC' || country.toUpperCase() === 'GT' || country.toUpperCase() === 'HN' || country.toUpperCase() === 'SV' || country.toUpperCase() === 'NI' || country.toUpperCase() === 'CR' || country.toUpperCase() === 'PA'){
            return (
              <Link
                key={ index }
                activeClassName={ cx(styles.subItem, styles.active) }
                className={ styles.subItem }
                to={ subItem.route }
              >
                { subItem.label[language] }
              </Link>
            );
          }
          break;
          case 2: //linio
            if( country.toUpperCase() === 'CO' || country.toUpperCase() === 'PE'){
              return (
                <a target="_blank" onClick={()=>this.showModal()} className={ styles.subItem }>{ subItem.label[language] }</a>
              );
            }
          break;
        }
      });
    }else {
      return subItems.map((subItem, index) => {
        return (
          <Link
            key={ index }
            activeClassName={ cx(styles.subItem, styles.active) }
            className={ styles.subItem }
            to={ subItem.route }
          >
            { subItem.label[language] }
          </Link>
        );
      });
    }    
  }

  renderAltMenuItems() {
    const { language, user, altStyleOption, signedIn } = this.props;
    const { headerOverlapsMenu, showFullMenu } = this.state;
let lang = 'es';
    let name = user && user.data ? (user.data.displayName ?  user.data.displayName : user.data.firstName) : "";
    const altMenuItems = name && name.length > 9 ? menuItems2 : menuItems;     
    const conf = name && name.length > 9 ? menuItemsConfig2 : menuItemsConfig; 
    debugger;
    return altMenuItems[lang].map((item, index) => {
      const menuItemClasses = cx(styles.altMenuItem,
        { [styles.altStyle]: altStyleOption && headerOverlapsMenu });

      return signedIn && user && user.data ? (
        <Link
          key={ index }
          className={ menuItemClasses }
          to={ conf[index].route }
          onClick={ () => { this.handleLinkClick(index); } }
        >
          { index !== 0 ? item : `${ capitalizeFirstLetter( name ) }`  }
        </Link>
      ):
        (index === 0 ?
        <IndexLink
          key={ index }
          className={ menuItemClasses }
          to={ loggedOutItems.join.route }
        >
          { loggedOutItems.join.label[language] }
        </IndexLink>:
        <Link
          key={ index }
          className={ menuItemClasses }
          to={ conf[index].route }
          onClick={ () => { this.handleLinkClick(index); } }
        >
          { item }
        </Link>)
    });
  }

  renderHeaderMenuItems() {
    return (
      <div className={ styles.headerMenu }>
        { this.renderAltMenuItems() }
      </div>
    );
  }

  /* sin Sign In */
  renderHeaderMenuItemsWitOutSignIn() {
    const { onlyHeaderNav, altStyleOption, airRedemptionPage, signedIn } = this.props;
    const { logoOffset, primaryMenuVisible, headerOverlapsMenu } = this.state;
    const logoImage = (altStyleOption && headerOverlapsMenu) ? darkLogoUrl : logoUrl;
    const offset = signedIn ? logoOffset : 0;

    const scrollTopMenu = document.documentElement.scrollTop > 50;

    return (
      <div>
        <div className={ styles.headerMenu }>
          { scrollTopMenu ? this.renderAltMenuItems() 
          : <div className={ styles.logo }>
              <Link to={ routeCodes.HOMEPAGE }>
                <img
                  style={ { transform: `translateY(${ offset }px)` } }
                  src={ logoImage }
                  alt='LifeMiles Logo'
                />
              </Link>
            </div>
          }
        </div>
      </div>
    );
  }

  renderLocalizationTrigger() {
    const {
      country,
      countries,
      altStyleOption,
      language,
    } = this.props;

    const {
      showLocalizationTooltip,
      headerOverlapsMenu,
    } = this.state;

    const buttonHolderClasses = cx(
      styles.headerSideButtonHolder,
      { [styles.altStyle]: altStyleOption && headerOverlapsMenu }
    );

    const countryKey = countries && countries[0] && countries.find(item =>{
      return item.iso2 == country;
    });
    
    let srcCountries = countryKey ? countryKey.iconUrl : '';
    let nameCountries = countryKey ? countryKey.name : '';

    return (
      <div className={ styles.headerSideItem }>
        <button
          className={ styles.button }
          onClick={ this.openLocalizationTooltip }
        >
          <div className={ buttonHolderClasses }>
            <img className={ styles.ballFlagIcon } src={ srcCountries} alt={ `${ nameCountries } flag icon` } />
            <span className={ styles.languageLabel }>{ literals.languageLabel[language] }</span>
          </div>
        </button>
        { showLocalizationTooltip &&
          <LocalizationTooltip
            positionWrapperClass={ styles.localizationTooltipWrapper }
            openModalHandler={ this.handleModalOpen }
            outsideClickHandler={ this.closeLocalizationTooltip }
          />
        }
      </div>
    );
  }

  renderProfileTrigger() {
    const {
      user,
      language,
      breakpoint,
      onlyHeaderNav,
      altStyleOption,
      airRedemptionPage,
    } = this.props;
    const { showProfileTooltip, primaryMenuVisible, headerOverlapsMenu } = this.state;
    const firstNameLetter = user && user.data && user.data.firstName && user.data.firstName[0];

    const isSmallorMedium = ['xs', 'sm', 'md'].includes(breakpoint);

    let showNameLabel = false;

    if (airRedemptionPage) {
      showNameLabel = onlyHeaderNav && !isSmallorMedium;
    } else {
      showNameLabel = onlyHeaderNav ? primaryMenuVisible /*&& (breakpoint !== 'sm')*/ :primaryMenuVisible;
    }

    const buttonClasses = cx(styles.headerSideButtonHolder, styles.button,
      { [styles.altStyle]: altStyleOption && headerOverlapsMenu });

    const arrowIcon = (altStyleOption && headerOverlapsMenu) ? arrowDownRed : arrowDown;

    const arrowClasses = cx(
      showProfileTooltip ? styles.arrowOpen : styles.arrow
    );
    
    let menuName = user && user.data ? (user.data.displayName ? `${ user.data.displayName.substring(0,1) }. ${ user.data &&  user.data.lastName }` : `${ user.data && user.data.firstName.substring(0,1) }. ${ user.data &&  user.data.lastName }`) : '';
    

    const imageAlt = showProfileTooltip ? 'Arrow up icon' : 'Arrow down icon';

    return user && user.data && (
      <div className={ styles.headerSideItem }>
        <button className={ styles.button } onClick={ this.openProfileTooltip }>
          <div className={ buttonClasses }>
            { showNameLabel && <span>{ menuName }</span> }
            <span className={ styles.bold }>LM { numberWithCommas(user.data && user.data.lifeMiles) }</span>
            <img
              src={ arrowIcon }
              alt={ imageAlt }
              className={ arrowClasses }
            />
          </div>
        </button>
        { showProfileTooltip &&
          <ProfileTooltip
            positionWrapperClass={ styles.profileTooltipWrapper }
            name={ menuName }
            status={ user.data &&  user.data.eliteStatus }
            lifemilesNo= { user.data &&  user.data.memberNumber }
            language={ language }
            logoutHandler={ this.handleLogout }
            outsideClickHandler={ this.closeProfileTooltip }
            itemClickHandler={ this.closeProfileTooltip }
            statusText={ user.data &&  user.data.cenitStatus }
          />
        }
      </div>
    );
  }

  renderLeftHeaderPart() {
    const { onlyHeaderNav, altStyleOption, airRedemptionPage, signedIn } = this.props;
    const { logoOffset, primaryMenuVisible, headerOverlapsMenu } = this.state;
    const showMenuItems = signedIn && (onlyHeaderNav || !primaryMenuVisible) && !airRedemptionPage;
    const logoImage = (altStyleOption && headerOverlapsMenu) ? darkLogoUrl : logoUrl;
    const offset = signedIn ? logoOffset : 0;

    return showMenuItems ? this.renderHeaderMenuItems() : this.renderHeaderMenuItemsWitOutSignIn();
 
  }

  renderRightHeaderPart() {
    const { language, signedIn, onlyHeaderNav, breakpoint } = this.props;
    const { primaryMenuVisible } = this.state;

    const showLocalizationTrigger = onlyHeaderNav ? primaryMenuVisible /*&& (breakpoint !== 'sm')*/ : primaryMenuVisible;
    const showSeparator = signedIn && showLocalizationTrigger;
    let rightSideItem;

    let routeOnlyPartnerAirline = location.pathname.split('/');
    let routeOnly = '/'+routeOnlyPartnerAirline[1]+'/'+routeOnlyPartnerAirline[2]+'/';

    if (signedIn) {
      rightSideItem = this.renderProfileTrigger();
    } else {
      const state = `{'Access-Level': '0', 'Redirect-Uri': ''}`;
      const lmOAuth = getOAuth2Object('lmLogin', state);
      rightSideItem = (
        <a className={ styles.login } href={ lmOAuth.token.getUri() }> { literals.signIn.LOGIN[language] }</a>
      );
    }

    return (
      <div className={ styles.headerRightWrapper }>
        { showLocalizationTrigger && this.renderLocalizationTrigger() }
        { showSeparator && <div className={ styles.separator } /> }
        { rightSideItem }
      </div>
    );
  }

  renderHeader() {
   
    return (
      <div className={ styles.header }>
        <div className={ styles.headerLeftWrapper }>
          { this.renderLeftHeaderPart() }
        </div>
        <div className={ styles.headerRightWrapper }>
          { this.renderRightHeaderPart() }
        </div>
      </div>
    );
  }

  renderMainMenu() {
    
    return (
      <div className={ styles.mainMenuWrapper }>
        <div
          ref={ node => { this.controlContainer = node; } }
          className={ styles.wrapper }
        >
          {
            <div>
              { this.renderHeader() }
              { this.renderPrimaryMenu() }
            </div>
          }
        </div>
      </div>
    );
  }

  render() {
    const menu = this.renderMainMenu();

    return menu;
  }
}

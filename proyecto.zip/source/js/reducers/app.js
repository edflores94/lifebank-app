import { Map } from 'immutable';
import { getBreakpoint } from 'decorators/ResizeManager';

import {
	DEFAULT_LANGUAGE,
	DEFAULT_COUNTRY,
	DEFAULT_CURRENCY
} from 'common/constants';

import { getIpAddress } from 'common/util';

import {
	FINISH_INITIAL_LOADING,
	SET_CONTEXTUALIZATION_MENU,
  SET_LANGUAGE,
  SET_CURRENTPAGE,
	SET_BIN,
	SET_MODAL,
  SET_IDSUBSCRIPTION,
	SET_COUNTRY,
	SET_CURRENCY,
  SET_BREAKPOINT,	
	GET_HOMEPAGE_DATA_ACTION_START,
	GET_HOMEPAGE_DATA_ACTION_ERROR,
	GET_HOMEPAGE_DATA_ACTION_SUCCESS,
	GET_CURRENCIES_BY_COUNTRY_ACTION_ERROR,
	GET_CURRENCIES_BY_COUNTRY_ACTION_SUCCESS,
	GET_CURRENCY_SYMBOL_ACTION_ERROR,
	GET_CURRENCY_SYMBOL_ACTION_SUCCESS,
	GET_ALL_COUNTRIES_ACTION_START,
	GET_ALL_COUNTRIES_ACTION_ERROR,
	GET_ALL_COUNTRIES_ACTION_SUCCESS,
	GET_ALL_DOCSTYPES_ACTION_START,
	GET_ALL_DOCSTYPES_ACTION_ERROR,
	GET_ALL_DOCSTYPES_ACTION_SUCCESS,
	GET_ALL_STATES_ACTION_START,
	GET_ALL_STATES_ACTION_ERROR,
	GET_ALL_STATES_ACTION_SUCCESS,
	GET_ALL_CITIES_ACTION_START,
	GET_ALL_CITIES_ACTION_ERROR,
	GET_ALL_CITIES_ACTION_SUCCESS,
	GET_ALL_DELIVERY_STATES_ACTION_START,
	GET_ALL_DELIVERY_STATES_ACTION_ERROR,
	GET_ALL_DELIVERY_STATES_ACTION_SUCCESS,
	GET_ALL_DELIVERY_CITIES_ACTION_START,
	GET_ALL_DELIVERY_CITIES_ACTION_ERROR,
	GET_ALL_DELIVERY_CITIES_ACTION_SUCCESS,
	GET_ALL_GENDER_ACTION_START,
	GET_ALL_GENDER_ACTION_ERROR,
	GET_ALL_GENDER_ACTION_SUCCESS,
	GET_ALL_PHONE_NUMBER_ACTION_START,
	GET_ALL_PHONE_NUMBER_ACTION_ERROR,
	GET_ALL_PHONE_NUMBER_ACTION_SUCCESS,
	GET_LAWS_PER_COUNTRY_ACTION_START,
	GET_LAWS_PER_COUNTRY_ACTION_ERROR,
	GET_LAWS_PER_COUNTRY_ACTION_SUCCESS,
	GET_ALL_LAWS_ACTION_START,
	GET_ALL_LAWS_ACTION_ERROR,
	GET_ALL_LAWS_ACTION_SUCCESS,
	GET_GDPR_COUNTRIES_ACTION_START,
	GET_GDPR_COUNTRIES_ACTION_ERROR,
	GET_GDPR_COUNTRIES_ACTION_SUCCESS,
	GET_MENU_COUNTRIES_ACTION_START,
	GET_MENU_COUNTRIES_ACTION_ERROR,
	GET_MENU_COUNTRIES_ACTION_SUCCESS,
	GET_PRIVACY_TERMS_MODAL_ACTION_START,
	GET_PRIVACY_TERMS_MODAL_ACTION_ERROR,
	GET_PRIVACY_TERMS_MODAL_ACTION_SUCCESS,
	GET_IP_ACTION_START ,
  GET_IP_ACTION_ERROR ,
	GET_IP_ACTION_SUCCESS ,
	GET_GOOGLE_MAPS_PLACES_LOGIN_ACTION_START,
	GET_GOOGLE_MAPS_PLACES_LOGIN_ACTION_ERROR,
	GET_GOOGLE_MAPS_PLACES_LOGIN_ACTION_SUCCESS,
	CLEAR_USER,
	LOGIN,
	USER_LOGGED_OUT,
	OPEN_PARTNER_SEARCH,
	CLOSE_PARTNER_SEARCH,
	HOMEPAGE_CIRCLES_HOVERED,
	SET_CHANNEL } from 'actions/app';

import {
	GET_GEOLOCATION_ACTION_START,
	GET_GEOLOCATION_ACTION_ERROR,
	GET_GEOLOCATION_ACTION_SUCCESS,
	GET_GOOGLE_MAPS_PLACES_ACTION_START,
	GET_GOOGLE_MAPS_PLACES_ACTION_ERROR,
	GET_GOOGLE_MAPS_PLACES_ACTION_SUCCESS
} from 'actions/geolocation';

const initialState = Map({
	initialLoading: false,	
	asyncLoading: false,
	asyncError: null,
	asyncData: null,
	currentPage: '',
	bin:'',
	modal: null,
	language: DEFAULT_LANGUAGE,
	country: '',
	currency: '',
	currencySymbol: null,
	geolocation: {},
	cookiesNotification: 'LifeMiles.com uses our own and third-party cookies to improve your experience and our services. If you continue, we consider that you accept their use. You can get more information in our privacy policy.',
	user: {
		miles: {}
	},
	signedIn: false,
	breakpoint: getBreakpoint(),
	homepageData: {
		background: {},
	},
	homepageCirclesHovered: false,
	countries: {},
	ibsCountries: [],
	partnerSearchOpened: false,
	partnerSearchInitCategory: null,
	partnerSearchInitCountry: null,
	getDocsTypes: [],
	getStates: '',
	getCities: '',
	getDeliveryStates: '',
	getDeliveryCities: '',
	ip: null,
	googleMapsPlaces: [],
	googleMapsPlacesLogin: [],
	showContextualizationMenu: true,
	lawsPerCountry:{},
	allLaws:{},
	gdprCountries:{},
	privacyTermsModal:{},
	channel: 'wst', // web/app channel
});

const actionsMap = {
	[FINISH_INITIAL_LOADING]: (state) => {
		return state.merge(Map({
			initialLoading: true
		}));
	},
	[SET_LANGUAGE]: (state, action) => {
		const { language } = action;
		return state.merge(Map({
			language
		}));
	},
	[SET_IDSUBSCRIPTION]: (state, action) => {
		const { idsubscription } = action;
		return state.merge(Map({
			idsubscription
		}));
	},
	[SET_CURRENTPAGE]: (state, action) => {
		const { currentPage } = action;
		return state.merge(Map({
			currentPage
		}));
	},
	[SET_BIN]: (state, action) => {
		const { bin } = action;
		return state.merge(Map({
			bin
		}));
	},
	[SET_MODAL]: (state, action) => {
		const { modal } = action;
		return state.merge(Map({
			modal
		}));
	},
	[SET_COUNTRY]: (state, action) => {
		return state.merge(Map({
			country: action.key
		}));
	},
	[SET_CURRENCY]: (state, action) => {
		return state.merge(Map({
			currency: action.currency
		}));
	},
	[SET_BREAKPOINT]: (state, action) => {
		return state.merge(Map({
			breakpoint: action.breakpoint
		}));
	},	
	[GET_HOMEPAGE_DATA_ACTION_START]: (state) => {
		return state.merge(Map({
			asyncLoading: true,
			asyncError: null,
			homepageData: {
				background: {}
			}
		}));
	},
	[GET_HOMEPAGE_DATA_ACTION_ERROR]: (state, action) => {
		return state.merge(Map({
			asyncLoading: false,
			asyncError: action.data
		}));
	},
	[GET_HOMEPAGE_DATA_ACTION_SUCCESS]: (state, action) => {
		return state.merge(Map({
			asyncLoading: false,
			homepageData: action.data.homepageData
		}));
	},
	[GET_MENU_COUNTRIES_ACTION_START]: (state) => {
		return state.merge({
			asyncLoading: true,
			asyncError: null
		});
	},
	[GET_MENU_COUNTRIES_ACTION_ERROR]: (state, action) => {
		return state.merge(Map({
			asyncLoading: false,
			asyncError: action.data
		}));
	},
	[GET_MENU_COUNTRIES_ACTION_SUCCESS]: (state, action) => {
		return state.merge(Map({
			asyncLoading: false,
			countries: action.data.countries
		}));
	},
	[GET_PRIVACY_TERMS_MODAL_ACTION_START]: (state) => {
		return state.merge({
			asyncLoading: true,
			asyncError: null
		});
	},
	[GET_PRIVACY_TERMS_MODAL_ACTION_ERROR]: (state, action) => {
		return state.merge(Map({
			asyncLoading: false,
			asyncError: action.data
		}));
	},
	[GET_PRIVACY_TERMS_MODAL_ACTION_SUCCESS]: (state, action) => {
		return state.merge(Map({
			asyncLoading: false,
			privacyTermsModal: action.data
		}));
	},
	[GET_GEOLOCATION_ACTION_START]: (state) => {
		return state.merge({});
	},
	[GET_GEOLOCATION_ACTION_ERROR]: (state, action) => {
		return state.merge(Map({
			geolocation: action.error
		}));
	},
	[GET_GEOLOCATION_ACTION_SUCCESS]: (state, action) => {
		return state.merge(Map({
			geolocation: action.data
		}));
	},
	
	[GET_LAWS_PER_COUNTRY_ACTION_START]: (state) => {
		return state.merge({
		  asyncLoading: true,
			asyncError: null,
		});
	},
	[GET_LAWS_PER_COUNTRY_ACTION_ERROR]: (state, action) => {
		return state.merge(Map({
			lawsPerCountry: action.error
		}));
	},
	[GET_LAWS_PER_COUNTRY_ACTION_SUCCESS]: (state, action) => {
		return state.merge(Map({
			lawsPerCountry: action.data
		}));
	},
	[GET_ALL_LAWS_ACTION_START]: (state) => {
		return state.merge({
		  asyncLoading: true,
			asyncError: null,
		 });
	},
	[GET_ALL_LAWS_ACTION_ERROR]: (state, action) => {
		return state.merge(Map({
			allLaws: action.error
		}));
	},
	[GET_ALL_LAWS_ACTION_SUCCESS]: (state, action) => {
		return state.merge(Map({
			allLaws: action.data
		}));
	},
	[GET_GDPR_COUNTRIES_ACTION_START]: (state) => {
		return state.merge({
		  asyncLoading: true,
			asyncError: null,
		 });
	},
	[GET_GDPR_COUNTRIES_ACTION_ERROR]: (state, action) => {
		return state.merge(Map({
			gdprCountries: action.error
		}));
	},
	[GET_GDPR_COUNTRIES_ACTION_SUCCESS]: (state, action) => {
		return state.merge(Map({
			gdprCountries: action.data
		}));
	},
	[CLEAR_USER]: (state) => {
		return state.merge(Map({
			user: null
		}));
	},
	[LOGIN]: (state) => {
		return state.merge(Map({
			signedIn: true
		}));
	},
	[USER_LOGGED_OUT]: (state) => {
		return state.merge(Map({
			signedIn: false
		}));
	},
	[OPEN_PARTNER_SEARCH]: (state, action) => {
		document.querySelector('html').className = 'noScrollable';
		// added to fix scrolling issues in iPhone 7+
		document.querySelector('body').className = 'noScrollable';
		return state.merge(Map({
			partnerSearchOpened: true,
			partnerSearchInitCategory: action.category,
			partnerSearchInitCountry: action.country,
		}));
	},
	[CLOSE_PARTNER_SEARCH]: (state) => {
		document.querySelector('html').className = '';
		// ^^
		document.querySelector('body').className = '';
		return state.merge(Map({
			partnerSearchOpened: false,
			partnerSearchInitCategory: null,
			partnerSearchInitCountry: null
		}));
	},
	[HOMEPAGE_CIRCLES_HOVERED]: (state, action) => {
		return state.merge(Map({
			homepageCirclesHovered: action.data
		}));
	},
	[GET_CURRENCIES_BY_COUNTRY_ACTION_ERROR]: (state,action)=>{
		return state.merge(Map({
			currencies:[]
		}));
	},
	[GET_CURRENCIES_BY_COUNTRY_ACTION_SUCCESS]: (state,action)=>{
		return state.merge(Map({
			currencies: action.data.items
		}));
	},
	[GET_CURRENCY_SYMBOL_ACTION_ERROR]: (state, action) => {
		return state.merge(Map({
			currencySymbol: null
		}));
	},
	[GET_CURRENCY_SYMBOL_ACTION_SUCCESS]: (state, action) => {
		return state.merge(Map({
			currencySymbol: action.data
		}));
	},
	[GET_ALL_COUNTRIES_ACTION_START]: (state) => {
    return state.merge({
      asyncLoading: true,
      asyncError: null,   
    });
  },
	[GET_ALL_COUNTRIES_ACTION_ERROR]: (state,action)=>{
		return state.merge(Map({
      ibsCountries: {
        asyncLoading: false,
        asyncError: action.error
      }
		}));
	},
	[GET_ALL_COUNTRIES_ACTION_SUCCESS]: (state,action)=>{
		return state.merge(Map({
			ibsCountries: action.data.countries
		}));
	},
	[GET_IP_ACTION_START]: (state) => {
		return state.merge({
		  asyncLoading: true,
		  asyncError: null,
		});
	},
	[GET_IP_ACTION_ERROR]: (state, action) => {
		return state.merge(Map({
			ip: action.error
		}));
	},
	[GET_IP_ACTION_SUCCESS]: (state, action)=>{
		return state.merge(Map({
			ip: action.data
		}));
	},
	[GET_ALL_DOCSTYPES_ACTION_START]: (state) => {
    return state.merge({
      asyncLoading: true,
      asyncError: null,   
    });
  },
  [GET_ALL_DOCSTYPES_ACTION_ERROR]: (state, action) => {
    return state.merge(Map({
			getDocsTypes: []
		}));
  },
  [GET_ALL_DOCSTYPES_ACTION_SUCCESS]: (state, action) => {
    return state.merge(Map({
			getDocsTypes: action.data.doctype
		}));
	},
	[GET_ALL_STATES_ACTION_START]: (state) => {
    return state.merge({
      asyncLoading: true,
      asyncError: null,   
    });
  },
  [GET_ALL_STATES_ACTION_ERROR]: (state, action) => {
    return state.merge(Map({
			getStates: []
		}));
  },
  [GET_ALL_STATES_ACTION_SUCCESS]: (state, action) => {
    return state.merge(Map({
			getStates: action.data
		}));
	},
	[GET_ALL_DELIVERY_STATES_ACTION_START]: (state) => {
    return state.merge({
      asyncLoading: true,
      asyncError: null,   
    });
  },
  [GET_ALL_DELIVERY_STATES_ACTION_ERROR]: (state, action) => {
    return state.merge(Map({
			getDeliveryStates: []
		}));
  },
  [GET_ALL_DELIVERY_STATES_ACTION_SUCCESS]: (state, action) => {
    return state.merge(Map({
			getDeliveryStates: action.data
		}));
	},
	[GET_ALL_DELIVERY_CITIES_ACTION_START]: (state) => {
    return state.merge({
      asyncLoading: true,
      asyncError: null,   
    });
  },
  [GET_ALL_DELIVERY_CITIES_ACTION_ERROR]: (state, action) => {
    return state.merge(Map({
			getDeliveryCities: []
		}));
  },
  [GET_ALL_DELIVERY_CITIES_ACTION_SUCCESS]: (state, action) => {
    return state.merge(Map({
			getDeliveryCities: action.data
		}));
	},
	[GET_ALL_CITIES_ACTION_START]: (state) => {
    return state.merge({
      asyncLoading: true,
      asyncError: null,   
    });
  },
  [GET_ALL_CITIES_ACTION_ERROR]: (state, action) => {
    return state.merge(Map({
			getCities: []
		}));
  },
  [GET_ALL_CITIES_ACTION_SUCCESS]: (state, action) => {
    return state.merge(Map({
			getCities: action.data
		}));
	},
	[GET_ALL_GENDER_ACTION_START]: (state) => {
    return state.merge({
      asyncLoading: true,
      asyncError: null,   
    });
  },
  [GET_ALL_GENDER_ACTION_ERROR]: (state, action) => {
    return state.merge(Map({
			getGender: []
		}));
  },
  [GET_ALL_GENDER_ACTION_SUCCESS]: (state, action) => {
    return state.merge(Map({
			getGender: action.data
		}));
	},
	[GET_ALL_PHONE_NUMBER_ACTION_START]: (state) => {
    return state.merge({
      asyncLoading: true,
      asyncError: null,   
    });
  },
  [GET_ALL_PHONE_NUMBER_ACTION_ERROR]: (state, action) => {
    return state.merge(Map({
			getPhoneNumber: []
		}));
  },
  [GET_ALL_PHONE_NUMBER_ACTION_SUCCESS]: (state, action) => {
    return state.merge(Map({
			getPhoneNumber: action.data
		}));
	},
	/**/
	[GET_GOOGLE_MAPS_PLACES_ACTION_START]: (state) => {
    return state.merge({
      asyncLoading: true,
      asyncError: null,
    });
  },
  [GET_GOOGLE_MAPS_PLACES_ACTION_ERROR]: (state, action) => {
    return state.merge(Map({
      asyncLoading: false,
      asyncError: action.data,
    }));
  },
  [GET_GOOGLE_MAPS_PLACES_ACTION_SUCCESS]: (state, action) => {
    return state.merge(Map({
      asyncLoading: false,
      googleMapsPlaces: action.data,
    }));
	},
	[GET_GOOGLE_MAPS_PLACES_LOGIN_ACTION_START]: (state) => {
    return state.merge({
      asyncLoading: true,
      asyncError: null,
    });
  },
  [GET_GOOGLE_MAPS_PLACES_LOGIN_ACTION_ERROR]: (state, action) => {
    return state.merge(Map({
      asyncLoading: false,
      asyncError: action.data,
    }));
  },
  [GET_GOOGLE_MAPS_PLACES_LOGIN_ACTION_SUCCESS]: (state, action) => {
    return state.merge(Map({
      asyncLoading: false,
      googleMapsPlacesLogin: action.data,
    }));
	},
	[SET_CONTEXTUALIZATION_MENU]: (state, action) => {
		return state.merge(Map({
			showContextualizationMenu: action.data
		}));
	},
	[SET_CHANNEL]: (state, action) => {
		return state.merge(Map({
			channel: action.data
		}));
	},
};

export default function reducer(state = initialState, action = {}) {
	const fn = actionsMap[action.type];
	return fn ? fn(state, action) : state;
}

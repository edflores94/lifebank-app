import { combineReducers } from 'redux';

import about from 'reducers/about';

export default combineReducers({
	about
});

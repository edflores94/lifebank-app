import AppValidator from 'validators/app';

const appValidator = new AppValidator();

export default appTransformer;

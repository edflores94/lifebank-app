import AboutLifemilesValidator from 'validators/about';

const aboutLifemilesValidator = new AboutLifemilesValidator();

const aboutLifemilesTransformer = {
  transformAboutLifemilesResponse: (data) => {
    const response = data;
    return aboutLifemilesValidator.validateAboutLifemilesResponse(response) ?
      response : null;
  },
};

export default aboutLifemilesTransformer;

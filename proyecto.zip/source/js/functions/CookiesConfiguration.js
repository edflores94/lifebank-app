import Cookies from 'universal-cookie';

export default class CookiesConfiguration {

	static selectCookieOptions(name) {
		const options = {
			path: "/",
			secure: false,
			httpOnly: false
		};
		
		const now = new Date();
		switch (name) {
			case 'defConf':
				now.setMonth( ( now.getMonth() + 1 ) + 6 );
				options.expires = now;
			break;	
			case 'lstpge':
				now.setDate( now.getDate() + 3 );
				options.expires = now;
			break;
			case 'bonusInfo':
				now.setDate( now.getDate() + 1 );
				options.expires = now;
			break;
			case 'ghostCardNumber':
				now.setDate( now.getDate() + 3 );
				options.expires = now;
			break;
			case 'dra3j':
				now.setDate( now.getDate() + 7 );
				options.expires = now;
			break;
			case 'emailStData':
				now.setDate( now.getDate() + 1 );
				options.expires = now;
			break;
			case 'userInfo':
				now.setDate( now.getDate() + 7 );
				options.expires = now;
			break;
			case 'creditCardCountry':
				now.setDate( now.getDate() + 3 );
				options.expires = now;
			break;
			case 'statusInfo':
				now.setDate( now.getDate() + 7 );
				options.expires = now;
			break;
			case "cookiePolicyAccepted":
				now.setMonth( ( now.getMonth() + 1 ) + 8 );
				options.expires = now;
			break;
		}
		return options;
	}

	static setConfigurationCookies(object) {
		const cookies = new Cookies();
		const options = this.selectCookieOptions('defConf');

		if (typeof(object) == "object") {
			cookies.set('defConf', object, options);
		}
	}

	static changeConfigurationCookies(object) {
		const cookies = new Cookies();
		const confCookies = cookies.get("defConf");

		if (typeof(object) == "object") {
			for (let key of Object.keys(object)) {
				if (confCookies[key] !== undefined) {
					confCookies[key] = object[key];
				}
			}
		}
		cookies.set('defConf', confCookies);
	}

	static getConfigurationCookies() {
		const cookies = new Cookies();
		const defConf = cookies.get('defConf');

		if (defConf) {
			const successType = typeof defConf.language == 'string' && typeof defConf.currency == 'string';
			return (successType && defConf.language && defConf.currency) ? defConf : false;
		}
		return false;
	}

	static getCookiePolicyAccepted() {
		const cookies = new Cookies();
		return cookies.get('cookiePolicyAccepted') ? false : true;
	}

	static setCookiePolicyAccepted() {
		const cookies = new Cookies();
		cookies.set('cookiePolicyAccepted', true, this.selectCookieOptions("cookiePolicyAccepted"));
	}	

	static getCookie(name) {
		const cookies = new Cookies();
		return (cookies.get(name) !== undefined) ? cookies.get(name) : false;
	}

	static setCookie(name, value) {
		const cookies = new Cookies();
		cookies.set(name, value, this.selectCookieOptions(name));
	}	

	static removeCookie(name) {
		const cookies = new Cookies();

		if (cookies.get(name) != undefined) {
			cookies.remove(name, { path: "/" });
			return true;
		} else{
			return false;
		}
	}
}

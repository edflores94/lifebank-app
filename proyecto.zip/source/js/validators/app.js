import BaseValidator from 'validators/base';


class AppValidator extends BaseValidator {
}

export default AppValidator;
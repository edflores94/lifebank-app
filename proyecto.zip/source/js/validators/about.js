import BaseValidator from 'validators/base';

import AboutLifemilesModel from 'models/About';

class AboutLifemilesValidator extends BaseValidator {

  validateAboutLifemilesResponse(data) {
    return this.validate(AboutLifemilesModel, data);
  }
}

export default AboutLifemilesValidator;

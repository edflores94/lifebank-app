export const publicPath = '/';

export const routeCodes = {
  HOMEPAGE: publicPath,
  SIGN_IN: `${ publicPath }sign-in`,
  SIGN_IN_WITH_ERROR: `${ publicPath }sign-in/(:ec)`,
  OAUTH2_SIGN_IN: `${ publicPath }oauth-signin`,
  FLY: `${ publicPath }fly`,
  FLY_PCO: `${ publicPath }fly/pco`,
  FORM_RESPONSE: `${ publicPath }formResponse/:id/:url/:type`,
  WATCHLIST_PATH_TO_AIR_REDEMPTION: `${ publicPath }wlc-air-redemption`,
  REGAINED_AIR_REDEMPTION_PAGE: `${ publicPath }rgnd-air-redemption`,
  AIR_REDEMPTION_NEW_SEARCH: `${ publicPath }nws-air-redemption`,
  AIR_REDEMPTION_PAGE: `${ publicPath }air-redemption`,
  GENERAL_ERROR:`${ publicPath }error/general`,
  MAINTENANCE:`${ publicPath }maintenance`,
  SSO_FLUX: `${ publicPath }sso-flux/:token/:page/:lang/:channel`
};

import { Map } from 'immutable';

export const DEFAULT_LANGUAGE = 'es';
export const DEFAULT_COUNTRY = 'co';
export const DEFAULT_CURRENCY = 'usd';

export const countryLabels = ['Afghanistan', 'Albania', 'Algeria', 'American Samoa', 'Andorra', 'Angola', 'Anguilla', 'Antigua & Barbuda', 'Argentina', 'Armenia', 'Aruba', 'Australia', 'Austria', 'Azerbaijan', 'Bahamas\, The', 'Bahrain', 'Bangladesh', 'Barbados', 'Belarus', 'Belgium', 'Belize', 'Benin', 'Bermuda', 'Bhutan', 'Bolivia', 'Bosnia & Herzegovina', 'Botswana', 'Brazil', 'British Virgin Is.', 'Brunei', 'Bulgaria', 'Burkina Faso', 'Burma', 'Burundi', 'Cambodia', 'Cameroon', 'Canada', 'Cape Verde', 'Cayman Islands', 'Central African Rep.', 'Chad', 'Chile', 'China', 'Colombia', 'Comoros', 'Congo\, Dem. Rep.', 'Congo\, Repub. of the', 'Cook Islands', 'Costa Rica', 'Cote d\'Ivoire', 'Croatia', 'Cuba', 'Cyprus', 'Czech Republic', 'Denmark', 'Djibouti', 'Dominica', 'Dominican Republic', 'East Timor', 'Ecuador', 'Egypt', 'El Salvador', 'Equatorial Guinea', 'Eritrea', 'Estonia', 'Ethiopia', 'Faroe Islands', 'Fiji', 'Finland', 'France', 'French Guiana', 'French Polynesia', 'Gabon', 'Gambia, The', 'Gaza Strip', 'Georgia', 'Germany', 'Ghana', 'Gibraltar', 'Greece', 'Greenland', 'Grenada', 'Guadeloupe', 'Guam', 'Guatemala', 'Guernsey', 'Guinea', 'Guinea-Bissau', 'Guyana', 'Haiti', 'Honduras', 'Hong Kong', 'Hungary', 'Iceland', 'India', 'Indonesia', 'Iran', 'Iraq', 'Ireland', 'Isle of Man', 'Israel', 'Italy', 'Jamaica', 'Japan', 'Jersey', 'Jordan', 'Kazakhstan', 'Kenya', 'Kiribati', 'Korea, North', 'Korea, South', 'Kuwait', 'Kyrgyzstan', 'Laos', 'Latvia', 'Lebanon', 'Lesotho', 'Liberia', 'Libya', 'Liechtenstein', 'Lithuania', 'Luxembourg', 'Macau', 'Macedonia', 'Madagascar', 'Malawi', 'Malaysia', 'Maldives', 'Mali', 'Malta', 'Marshall Islands', 'Martinique', 'Mauritania', 'Mauritius', 'Mayotte', 'Mexico', 'Micronesia\, Fed. St.', 'Moldova', 'Monaco', 'Mongolia', 'Montserrat', 'Morocco', 'Mozambique', 'Namibia', 'Nauru', 'Nepal', 'Netherlands', 'Netherlands Antilles', 'New Caledonia', 'New Zealand', 'Nicaragua', 'Niger', 'Nigeria', 'N. Mariana Islands', 'Norway', 'Oman', 'Pakistan', 'Palau', 'Panama', 'Papua New Guinea', 'Paraguay', 'Peru', 'Philippines', 'Poland', 'Portugal', 'Puerto Rico', 'Qatar', 'Reunion', 'Romania', 'Russia', 'Rwanda', 'Saint Helena', 'Saint Kitts & Nevis', 'Saint Lucia', 'St Pierre & Miquelon', 'Saint Vincent and the', 'Grenadines', 'Samoa', 'San Marino', 'Sao Tome & Principe', 'Saudi Arabia', 'Senegal', 'Serbia', 'Seychelles', 'Sierra Leone', 'Singapore', 'Slovakia', 'Slovenia', 'Solomon Islands', 'Somalia', 'South Africa', 'Spain', 'Sri Lanka', 'Sudan', 'Suriname', 'Swaziland', 'Sweden', 'Switzerland', 'Syria', 'Taiwan', 'Tajikistan', 'Tanzania', 'Thailand', 'Togo', 'Tonga', 'Trinidad & Tobago', 'Tunisia', 'Turkey', 'Turkmenistan', 'Turks & Caicos Is', 'Tuvalu', 'Uganda', 'Ukraine', 'United Arab Emirates', 'United Kingdom', 'United States', 'Uruguay', 'Uzbekistan', 'Vanuatu', 'Venezuela', 'Vietnam', 'Virgin Islands', 'Wallis and Futuna', 'West Bank', 'Western Sahara', 'Yemen', 'Zambia', 'Zimbabwe'];

export const LANGUAGE_EN = 'en';
export const LANGUAGE_ES = 'es';

export const prefLanguage= {
	EN: {
		en: "English",
		es: "Spanish",
	},
	ES: {
		en: "Spanish",
		es: "Español",
	}, 
};

export const preferredLanguage = {
	en:["English", "Spanish", "Portuguese"],
	es:["Inglés", "Español", "Portugues"]
}

export const obligatoryZPCountry = [ {  //ZipCode Validation for obligatory countries
		countryName: 'Mexico', 
		countryCode: 'MX',
		regex: '^\\d{5}$',
		obligatory: false,
	}, 
	{
		regex: '^[A-Z][0-9][A-Z] [0-9][A-Z][0-9]$',
		countryName: 'Canada',
		countryCode: 'CA',
		obligatory: true,
	},
	{
		regex: '^\\d{5}$',
		countryName: 'España',
		countryCode: 'ES',
		obligatory: false,
	},
	{
		regex: '^[0-9]{5}(?:[-][0-9]{4})?$',
		countryName: 'Estados Unidos',
		countryCode: 'US',
		obligatory: true,
	},
	{
		regex: '^[A-Z0-9 ]{6,8}$',
		countryName: 'Reino unido',
		countryCode: 'GB',
		obligatory: false,
	},
]

export const AVIANCA_GOAL = 15000;
export const STAR_ALLIANCE_GOAL = 75000;
export const SEGMENTS_GOAL = 85;

export const BREAKPOINTS = {
	sm: 768,
	md: 1024,
	lg: 1280,
	xl: 1400,
	xxl: 1700
};

export const eliteStatus = {
	MEMBER: 'LIFEMILES',
	SILVER: 'SILVER',
	GOLD: 'GOLD',
	DIAMOND: 'DIAMOND',
	CENITGOLD: 'CENITGOLD',
	DIAMONDONE: 'DIAMONDONE',
	DIAMONDTWO: 'DIAMONDTWO',
};

export const CMS_MODULES_TYPES = {
	textBlock: 'text-block',
	bulletList: 'bullet-list',
	twoColumnTable: 'table',
	twoColumnList: '2-column-list',
	locationChart: 'location-chart',
	flightModule: 'flight-module',
	map: 'location-map'
};

export const AUTO_COMPLETE_KEY_ACTIONS = {
	UP: 'previous_action',
	DOWN: 'next_action',
	ENTER: 'select_action'
};

export const cardTypes = {
	VISA: 'VI',
	MASTERCARD: 'CA',
	AMEX: 'AX',
	DINERSCLUB: 'DC',
	DISCOVER: 'DS'
};

export const cardTypesNumber = {
	VISA: '001',
	MASTERCARD: '002',
	AMEX: '003',
	DINERSCLUB: '005',
	DISCOVER: '004'
};


export const cardRegex = {
	VISA: /^4[0-9]{12}(?:[0-9]{3})?$/,
	MASTERCARD: /^(?:5[1-5][0-9]{2}|222[1-9]|22[3-9][0-9]|2[3-6][0-9]{2}|27[01][0-9]|2720)[0-9]{12}$/,
	AMEX: /^3[47][0-9]{13}$/,
	DINERSCLUB:/^3(?:0[0-5]|[68][0-9])[0-9]{11}$/,
	DISCOVER: /^6(?:011|5[0-9]{2})[0-9]{12}$/
};

export const countries = {
	0: { value: 'ar', en: 'Argentina', es: 'Argentina' },
	1: { value: 'br', en: 'Brazil', es: 'Brasil' },
	2: { value: 'ca', en: 'Canada', es: 'Canadá' },
	3: { value: 'co', en: 'Colombia', es: 'Colombia' },
	4: { value: 'sv', en: 'El Salvador', es: 'El Salvador' },
	5: { value: 'gt', en: 'Guatemala', es: 'Guatemala' },
	6: { value: 'hn', en: 'Honduras', es: 'Honduras' },
	7: { value: 'ni', en: 'Nicaragua', es: 'Nicaragua' },
	8: { value: 'pa', en: 'Panama', es: 'Panamá' },
	9: { value: 'pe', en: 'Peru', es: 'Perú' },
	10: { value: 'us', en: 'United States', es: 'Estados Unidos' }
};

export const countriesArray = [
	{ value: 'ar', en: 'Argentina', es: 'Argentina' },
	{ value: 'br', en: 'Brazil', es: 'Brasil' },
	{ value: 'ca', en: 'Canada', es: 'Canadá' },
	{ value: 'co', en: 'Colombia', es: 'Colombia' },
	{ value: 'sv', en: 'El Salvador', es: 'El Salvador' },
	{ value: 'gt', en: 'Guatemala', es: 'Guatemala' },
	{ value: 'hn', en: 'Honduras', es: 'Honduras' },
	{ value: 'ni', en: 'Nicaragua', es: 'Nicaragua' },
	{ value: 'pa', en: 'Panama', es: 'Panamá' },
	{ value: 'pe', en: 'Peru', es: 'Perú' },
	{ value: 'us', en: 'United States', es: 'Estados Unidos' }
];
 
export const itemsModal =[
	{ page:"DRIVE", title:{en:"You are leaving LifeMiles main site", es:"Estás abandonando el sitio principal de LifeMiles"},subtitle:{en:"You are being redirected to a site operated by Rocketmiles, one of LifeMiles commercial partners.",es:"Está siendo redirigido un sitio propiedad de Rocketmiles, un comercial comercial de LifeMiles."},message:{en:"Transactions completed in this site will be carried out with Rocketmiles and the Terms and conditions specified in such site will apply. By continuing, you accept that any necessary information will be shared with Rocketmiles to enable the accrual and/or redemption of miles.",es:"Las transacciones que realices en este sitio serán con RocketMiles y sus Términos y Condiciones. Al proceder, datos necesarios para facilitar la acreditación y / o redención de millas, serán compartidos con Rocketmiles."}},
	{ page:"SHOPPING_PARTNERS", title:{en:"You are leaving LifeMiles main site", es:"Estás abandonando el sitio principal de LifeMiles"},subtitle:{en:"You are being redirected to a site operated by Linio Colombia SAS (Linio), one of LifeMiles commercial partners.",es:"Estás siendo redirigido un sitio propiedad de Linio Colombia SAS (Linio), un socio comercial de LifeMiles."},message:{en:"Transactions completed in this site will be carried out with Linio and the Terms and Conditions specified in such site will apply. By continuing, you accept these Terms and Conditions and you acknowledge that any necessary information will be shared with Linio to enable the redemption of miles transactions.",es:"Las transacciones que realices en este sitio serán con Linio y aplicarán los Términos y Condiciones allí especificados. Al proceder, aceptas estos Términos y Condiciones y aceptas que se comparta con Linio los datos necesarios para facilitar tu redención de millas."}},
	{ page:"SHOPPING_PARTNERS", title:{en:"You are leaving LifeMiles main site", es:"Estás abandonando el sitio principal de LifeMiles"},subtitle:{en:"You are being redirected to a site operated by Linio Peru SAS (Linio), one of LifeMiles commercial partners.",es:"Estás siendo redirigido un sitio propiedad de Linio Perú SAS (Linio), un socio comercial de LifeMiles."},message:{en:"Transactions completed in this site will be carried out with Linio and the Terms and Conditions specified in such site will apply. By continuing, you accept these Terms and Conditions and you acknowledge that any necessary information will be shared with Linio to enable the redemption of miles transactions.",es:"Las transacciones que realices en este sitio serán con Linio y aplicarán los Términos y Condiciones allí especificados. Al proceder, aceptas estos Términos y Condiciones y aceptas que se comparta con Linio los datos necesarios para facilitar tu redención de millas."}}
]

export const regions = {
	en: ['Africa', 'Asia', 'Central America', 'Eastern Europe','European Union', 'Middle East', 'North America', 'Oceania', 'South America', 'The Caribbean'],
	es: ['África', 'Asia', 'América Central', 'Europa del Este', 'Unión Europea', 'Medio Oriente', 'América del Norte', 'Oceanía', 'América del Sur', 'El Caribe']};
	
export const rsaPublicReduxKey = '-----BEGIN RSA PUBLIC KEY-----\n' +
	'MEgCQQCaw5HyjOiNQtCyDpPC6DGozXP9OovWB9MbYwfyghvT411ds0UZzEvau06B' +
	'bVUqGdcikGo7YSqJLfY/cSvwYUndAgMBAAE=\n' +
	'-----END RSA PUBLIC KEY-----';	

export const rsaPrivateReduxKey = '-----BEGIN RSA PRIVATE KEY-----\n' +
	'MIIBOwIBAAJBAJrDkfKM6I1C0LIOk8LoMajNc/06i9YH0xtjB/KCG9PjXV2zRRnM' +
	'S9q7ToFtVSoZ1yKQajthKokt9j9xK/BhSd0CAwEAAQJAIvnN0w4LRFl0RrlKpYLK' +
	'Lkb4TqNblOxBxm+0DRdgaJseFCQ2zZ6sZgcoAz5MtXsitM6Cfh9+K1LBVn18qi75' + 
	'9QIhAP1y9rIEDXTbiaIQscSodf3K1bUT882bth7VoARYWd/3AiEAnFJVpYfDQ6ta' +
	'2C4uoL2EHIuuwkd9d5DtsVTan7WOl8sCIQC+TOvejhxsecrF3TMdLkAp53q/E9Qj' +
	'tZ7xWAVmPdB90QIhAJVQ8A5VR+bzXqrwMgnH/NFne16H+wiinuisLMgxHCtRAiAA' +
	'rEQVGJj0KF8yM8+S/MvtsGR+1WQAI9k/9TTuTRsodA==\n' +
	'-----END RSA PRIVATE KEY-----';

export const countryCodes = {
	'ar': '0101',
	'br': '0102',
	'co': '0103',
	'cl': '0104',
	'cr': '0230',
	'ec': '0620',
	'sv': '0105',
	'gt': '0820',
	'hn': '0107',
	'ni': '0108',
	'pa': '0110',
	'pe': '0111',
	'us': '0070',
	'uy': '0112'
};

export const iflyCountries = [
	{ name: 'Argentina', value: '0101' },
	{ name: 'Brazil', value: '0102' },
	{ name: 'Colombia', value: '0103' },
	{ name: 'Chile', value: '0104' },
	{ name: 'Ecuador', value: '0620' },
	{ name: 'El Salvador', value: '0105' },
	{ name: 'Guatemala', value: '0820' },
	{ name: 'Honduras', value: '0107' },
	{ name: 'Nicaragua', value: '0108' },
	{ name: 'Panama', value: '0110' },
	{ name: 'Peru', value: '0111' },
	{ name: 'United States', value: '0070' },
	{ name: 'Uruguay', value: '0012' },
];

export const redressCountries = [
	{
		name: {
			en: 'United States',
			es: 'Estados Unidos'
		},
		value: 'usa',
		countryCode:'0100'
	}
];

export const appMonthsFormat = {
	'01': {
		en: 'January',
		es: 'Enero'
	},
	'02': {
		en: 'February',
		es: 'Febrero'
	},
	'03': {
		en: 'March',
		es: 'Marzo'
	},	
	'04': {
		en: 'April',
		es: 'Abril'
	},
	'05': {
		en: 'May',
		es: 'Mayo'
	},	
	'06': {
		en: 'June',
		es: 'Junio'
	},	
	'07': {
		en: 'July',
		es: 'Julio'
	},
	'08': {
		en: 'August',
		es: 'Agosto'
	},
	'09': {
		en: 'September',
		es: 'Septiembre'
	},
	'10': {
		en: 'October',
		es: 'Octubre'
	},
	'11': {
		en: 'November',
		es: 'Noviembre'
	},
	'12': {
		en: 'December',
		es: 'Diciembre'
	}
};

export const documentTypes = {
	en: [
		{ name: 'National ID', value: 'I' },
		{ name: 'Driver License', value: 'D' },
		{ name: 'Passport', value: 'P' },
		{ name: 'VISA', value: 'V' },,
		{ name: 'Others', value: 'O' },
	],
	es: [
		{ name: 'Documento de Identificación Nacional', value: 'I' },
		{ name: 'Licencia de Conducir', value: 'D' },
		{ name: 'Pasaporte', value: 'P' },
		{ name: 'VISA', value: 'V' },
		{ name: 'Otros', value: 'O' },
	]
};

export const iflyAreaCodes = [
	{ longName: '+503 El Salvador', shortName: '+503 El Salvador', value: '503'},
	{ longName: '+502 Guatemala', shortName: '+502 Guatemala', value: '502'},
	{ longName: '+57 Colombia', shortName: '+57 Colombia', value: '57'}
];

export const iflyLanguages = [
	{
		name: {
			en: 'Spanish',
			es: 'Español',
		},
		value: 'ES'
	},
	{
		name: {
			en: 'English',
			es: 'Ingles'
		},
		value: 'EN'
	}
];

export const categoryLabels={
	en: ['Activities','Auto Shop & Gas Stations','Courier','Health and Beauty','Hotels','Restaurants','Stores','Other' ],
	es: ['Actividades','Tienda de autos y gasolineras','Mensajería','Salud y belleza','Hoteles','Restaurantes','Tiendas','Otros']
};

export const becomePartnerCountryLabels={
	en: [
		'Argentina',
		'Belize',
		'Bolivia',
		'Brazil',
		'Chile',
		'Colombia',
		'Costa Rica',
		'Cuba',
		'Dominican Republic',
		'Ecuador',
		'El Salvador',
		'Guatemala',
		'Honduras',
		'Mexico',
		'Nicaragua',
		'Panama',
		'Paraguay',
		'Peru',
		'United States',
		'Uruguay',
		'Venezuela', 
		'Other'
	 ],
	es: [	
		'Argentina',
		'Belice',
		'Bolivia',
		'Brasil',
		'Chile',
		'Colombia',
		'Costa Rica',
		'Cuba',
		'República Dominicana',
		'Ecuador',
		'El Salvador',
		'Guatemala',
		'Honduras',
		'México',
		'Nicaragua',
		'Panamá',
		'Paraguay',
		'Perú',
		'Estados Unidos',
		'Uruguay',
		'Venezuela',
		'Otro'
	]
};

export const bookingGenders = [
	{
		genderName: {
			en: 'Male',
			es: 'Masculino'
		},
		genderValue: 'M',
		titleValue: 'MR'
	},
	{
		genderName: {
			en: 'Female',
			es: 'Femenino'
		},
		genderValue: 'F',
		titleValue: 'MS'
	}
];

/**
 * This stages represents the visual steps the user will see in the air redemption process.
 * If an additional step would want to be added in the process, it must be added to 
 * this map.
 */

export const AIR_REDEMPTION_STAGES = Map({
	BOOKER: 0,
	HEADER: 1,
	DEPARTING_DATE: 2,
	ARRIVAL_DATE: 3,
	FLIGHTS: 4,
	FLEXIBLE_PAYMENT: 5,
	TRAVELERS: 6,
	REDEEM: 7,
	CONFIRMATION: 8
});

export const TRIP_TYPES = Map({
	TRIP_ROUND: 'RT',
  TRIP_ONE_WAY: 'OW',
  TRIP_MULTI_CITY: 'MC'
});

export const REDEMPTION_CONTEXT = Map({
	CURRENT_FLIGHTS: 'D',
	PREV_FLIGHTS: 'P',
	NEXT_FLIGHTS: 'N',
	FLEXIBLE_PAYMENT: 'F', 
	TRAVELERS: 'C',
	REDEEM: 'R'
});

export const REDEMPTION_AGENT = 'p-portal';

export const SEAT_ALERT = 5;

export const TRAVELERS_COUNTRIES_CONTACT_ES = [
	{
		"id": "AF",
		"name": "Afganistán"
	},
	{
		"id": "AL",
		"name": "Albania"
	},
	{
		"id": "DE",
		"name": "Alemania (+49)"
	},
	{
		"id": "AD",
		"name": "Andorra (+376)"
	},
	{
		"id": "AO",
		"name": "Angola (+244)"
	},
	{
		"id": "AI",
		"name": "Anguila (+1264)"
	},
	{
		"id": "AG",
		"name": "Antigua y Barbuda (+1268)"
	},
	{
		"id": "AN",
		"name": "Antillas Holandesas"
	},
	{
		"id": "SA",
		"name": "Arabia Saudita (+966)"
	},
	{
		"id": "DZ",
		"name": "Argelia (+213)"
	},
	{
		"id": "AR",
		"name": "Argentina (+54)"
	},
	{
		"id": "AM",
		"name": "Armenia (+374)"
	},
	{
		"id": "AW",
		"name": "Aruba (+297)"
	},
	{
		"id": "AU",
		"name": "Australia (+61)"
	},
	{
		"id": "AT",
		"name": "Austria (+43)"
	},
	{
		"id": "AZ",
		"name": "Azerbaiyán (+994)"
	},
	{
		"id": "BS",
		"name": "Bahamas (+1242)"
	},
	{
		"id": "BD",
		"name": "Bangladesh (+880)"
	},
	{
		"id": "BB",
		"name": "Barbados (+1246)"
	},
	{
		"id": "BH",
		"name": "Baréin (+973)"
	},
	{
		"id": "BE",
		"name": "Bélgica (+32)"
	},
	{
		"id": "BZ",
		"name": "Belice (+501)"
	},
	{
		"id": "BJ",
		"name": "Benín (+229)"
	},
	{
		"id": "BM",
		"name": "Bermudas (+1441)"
	},
	{
		"id": "BY",
		"name": "Bielorrusia (+375)"
	},
	{
		"id": "BO",
		"name": "Bolivia (+591)"
	},
	{
		"id": "BQ",
		"name": "Bonaire, San Estaquio y Saba"
	},
	{
		"id": "BA",
		"name": "Bosnia-Herzegovina (+387)"
	},
	{
		"id": "BW",
		"name": "Botsuana (+267)"
	},
	{
		"id": "BR",
		"name": "Brasil (+55)"
	},
	{
		"id": "BN",
		"name": "Brunéi Darussalam (+673)"
	},
	{
		"id": "BG",
		"name": "Bulgaria (+359)"
	},
	{
		"id": "BF",
		"name": "Burkina Faso (+226)"
	},
	{
		"id": "BI",
		"name": "Burundi (+257)"
	},
	{
		"id": "CV",
		"name": "Cabo Verde (+238)"
	},
	{
		"id": "KH",
		"name": "Camboya (+855)"
	},
	{
		"id": "CM",
		"name": "Camerún (+237)"
	},
	{
		"id": "CA",
		"name": "Canadá (+1)"
	},
	{
		"id": "TD",
		"name": "Chad"
	},
	{
		"id": "CL",
		"name": "Chile (+56)"
	},
	{
		"id": "CN",
		"name": "China (+86)"
	},
	{
		"id": "CY",
		"name": "Chipre (+90392)"
	},
	{
		"id": "CO",
		"name": "Colombia (+57)"
	},
	{
		"id": "KM",
		"name": "Comoras (+269)"
	},
	{
		"id": "CG",
		"name": "Congo (+242)"
	},
	{
		"id": "CD",
		"name": "Congo"
	},
	{
		"id": "KP",
		"name": "Corea del Norte (+850)"
	},
	{
		"id": "KR",
		"name": "Corea del Sur (+82)"
	},
	{
		"id": "CI",
		"name": "Costa de Marfil"
	},
	{
		"id": "CR",
		"name": "Costa Rica (+506)"
	},
	{
		"id": "HR",
		"name": "Croacia (+385)"
	},
	{
		"id": "CU",
		"name": "Cuba (+53)"
	},
	{
		"id": "CW",
		"name": "Curazao"
	},
	{
		"id": "DK",
		"name": "Dinamarca (+45)"
	},
	{
		"id": "EC",
		"name": "Ecuador (+593)"
	},
	{
		"id": "EG",
		"name": "Egipto (+20)"
	},
	{
		"id": "SV",
		"name": "El Salvador (+503)"
	},
	{
		"id": "AE",
		"name": "Emiratos Árabes Unidos (+971)"
	},
	{
		"id": "ER",
		"name": "Eritrea (+291)"
	},
	{
		"id": "SK",
		"name": "Eslovaquia (+421)"
	},
	{
		"id": "SI",
		"name": "Eslovenia (+386)"
	},
	{
		"id": "ES",
		"name": "España (+34)"
	},
	{
		"id": "US",
		"name": "Estados Unidos (+1)"
	},
	{
		"id": "EE",
		"name": "Estonia (+372)"
	},
	{
		"id": "ET",
		"name": "Etiopía (+251)"
	},
	{
		"id": "PH",
		"name": "Filipinas (+63)"
	},
	{
		"id": "FI",
		"name": "Finlandia (+358)"
	},
	{
		"id": "FJ",
		"name": "Fiyi (+679)"
	},
	{
		"id": "FR",
		"name": "Francia (+33)"
	},
	{
		"id": "GA",
		"name": "Gabón (+241)"
	},
	{
		"id": "GM",
		"name": "Gambia (+220)"
	},
	{
		"id": "GE",
		"name": "Georgia (+7880)"
	},
	{
		"id": "GH",
		"name": "Ghana (+233)"
	},
	{
		"id": "GI",
		"name": "Gibraltar (+350)"
	},
	{
		"id": "GD",
		"name": "Granada (+1473)"
	},
	{
		"id": "GR",
		"name": "Grecia (+30)"
	},
	{
		"id": "GP",
		"name": "Guadalupe (+590)"
	},
	{
		"id": "GU",
		"name": "Guam (+671)"
	},
	{
		"id": "GT",
		"name": "Guatemala (+502)"
	},
	{
		"id": "GF",
		"name": "Guayana Francesa (+594)"
	},
	{
		"id": "GN",
		"name": "Guinea (+224)"
	},
	{
		"id": "GW",
		"name": "Guinea-Bissau (+245)"
	},
	{
		"id": "GQ",
		"name": "Guinea Ecuatorial (+240)"
	},
	{
		"id": "GY",
		"name": "Guyana (+592)"
	},
	{
		"id": "HT",
		"name": "Haití (+509)"
	},
	{
		"id": "NL",
		"name": "Holanda (+31)"
	},
	{
		"id": "HN",
		"name": "Honduras (+504)"
	},
	{
		"id": "HK",
		"name": "Hong Kong (+852)"
	},
	{
		"id": "HU",
		"name": "Hungría (+36)"
	},
	{
		"id": "IN",
		"name": "India (+91)"
	},
	{
		"id": "ID",
		"name": "Indonesia (+62)"
	},
	{
		"id": "IR",
		"name": "Irán (+98)"
	},
	{
		"id": "IQ",
		"name": "Iraq (+964)"
	},
	{
		"id": "IE",
		"name": "Irlanda (+353)"
	},
	{
		"id": "IS",
		"name": "Islandia (+354)"
	},
	{
		"id": "NF",
		"name": "Isla Norfolk (+672)"
	},
	{
		"id": "KY",
		"name": "Islas Caimán (+1345)"
	},
	{
		"id": "CK",
		"name": "Islas Cook (+682)"
	},
	{
		"id": "FO",
		"name": "Islas Feroe (+298)"
	},
	{
		"id": "FK",
		"name": "Islas Malvinas (+500)"
	},
	{
		"id": "MP",
		"name": "Islas Marianas"
	},
	{
		"id": "MH",
		"name": "Islas Marshall (+692)"
	},
	{
		"id": "PW",
		"name": "Islas Palaos (+680)"
	},
	{
		"id": "SB",
		"name": "Islas Salomón (+677)"
	},
	{
		"id": "TC",
		"name": "Islas Turcas y Caicos (+1649)"
	},
	{
		"id": "VG",
		"name": "Islas Vírgenes Británicas (+84)"
	},
	{
		"id": "VI",
		"name": "Islas Vírgenes de los Estados Unidos (+84)"
	},
	{
		"id": "IL",
		"name": "Israel (+972)"
	},
	{
		"id": "IT",
		"name": "Italia (+39)"
	},
	{
		"id": "JM",
		"name": "Jamaica (+1876)"
	},
	{
		"id": "JP",
		"name": "Japón (+81)"
	},
	{
		"id": "JO",
		"name": "Jordania (+962)"
	},
	{
		"id": "KZ",
		"name": "Kazajistán (+7)"
	},
	{
		"id": "KE",
		"name": "Kenia (+254)"
	},
	{
		"id": "KG",
		"name": "Kirguistán (+996)"
	},
	{
		"id": "KW",
		"name": "Kuwait (+965)"
	},
	{
		"id": "LA",
		"name": "Laos (+856)"
	},
	{
		"id": "LS",
		"name": "Lesoto (+266)"
	},
	{
		"id": "LV",
		"name": "Letonia (+371)"
	},
	{
		"id": "LB",
		"name": "Líbano (+961)"
	},
	{
		"id": "LR",
		"name": "Liberia (+231)"
	},
	{
		"id": "LY",
		"name": "Libia (+218)"
	},
	{
		"id": "LT",
		"name": "Lituania (+370)"
	},
	{
		"id": "LU",
		"name": "Luxemburgo (+352)"
	},
	{
		"id": "MO",
		"name": "Macao (+853)"
	},
	{
		"id": "MK",
		"name": "Macedonia (+389)"
	},
	{
		"id": "MG",
		"name": "Madagascar (+261)"
	},
	{
		"id": "MY",
		"name": "Malasia (+60)"
	},
	{
		"id": "MW",
		"name": "Malaui (+265)"
	},
	{
		"id": "MV",
		"name": "Maldivas (+960)"
	},
	{
		"id": "ML",
		"name": "Malí (+223)"
	},
	{
		"id": "MT",
		"name": "Malta (+356)"
	},
	{
		"id": "MA",
		"name": "Marruecos (+212)"
	},
	{
		"id": "MQ",
		"name": "Martinica (+596)"
	},
	{
		"id": "MU",
		"name": "Mauricio"
	},
	{
		"id": "MR",
		"name": "Mauritania (+222)"
	},
	{
		"id": "MX",
		"name": "México (+52)"
	},
	{
		"id": "FM",
		"name": "Micronesia (+691)"
	},
	{
		"id": "MD",
		"name": "Moldavia (+373)"
	},
	{
		"id": "MC",
		"name": "Monaco (+377)"
	},
	{
		"id": "MN",
		"name": "Mongolia (+976)"
	},
	{
		"id": "ME",
		"name": "Montenegro"
	},
	{
		"id": "MS",
		"name": "Montserrat (+1664)"
	},
	{
		"id": "MZ",
		"name": "Mozambique (+258)"
	},
	{
		"id": "MM",
		"name": "Myanmar"
	},
	{
		"id": "NA",
		"name": "Namibia (+264)"
	},
	{
		"id": "NR",
		"name": "Nauru (+674)"
	},
	{
		"id": "NP",
		"name": "Nepal (+977)"
	},
	{
		"id": "NI",
		"name": "Nicaragua (+505)"
	},
	{
		"id": "NE",
		"name": "Níger (+227)"
	},
	{
		"id": "NG",
		"name": "Nigeria (+234)"
	},
	{
		"id": "NU",
		"name": "Niue (+683)"
	},
	{
		"id": "NO",
		"name": "Noruega (+47)"
	},
	{
		"id": "NC",
		"name": "Nueva Caledonia (+687)"
	},
	{
		"id": "NZ",
		"name": "Nueva Zelanda (+64)"
	},
	{
		"id": "OM",
		"name": "Omán (+968)"
	},
	{
		"id": "PK",
		"name": "Pakistán"
	},
	{
		"id": "PA",
		"name": "Panamá (+507)"
	},
	{
		"id": "PG",
		"name": "Papua New Guinea (+675)"
	},
	{
		"id": "PY",
		"name": "Paraguay (+595)"
	},
	{
		"id": "PE",
		"name": "Perú (+51)"
	},
	{
		"id": "PF",
		"name": "Polinesia Francesa (+689)"
	},
	{
		"id": "PL",
		"name": "Polonia (+48)"
	},
	{
		"id": "PT",
		"name": "Portugal (+351)"
	},
	{
		"id": "PR",
		"name": "Puerto Rico (+1787)"
	},
	{
		"id": "QA",
		"name": "Qatar (+974)"
	},
	{
		"id": "GB",
		"name": "Reino Unido (+44)"
	},
	{
		"id": "CF",
		"name": "República Centroafricana (+236)"
	},
	{
		"id": "CZ",
		"name": "República Checa (+42)"
	},
	{
		"id": "DO",
		"name": "República Dominicana (+1809)"
	},
	{
		"id": "RE",
		"name": "Reunión (+262)"
	},
	{
		"id": "RW",
		"name": "Ruanda (+250)"
	},
	{
		"id": "RO",
		"name": "Rumania (+40)"
	},
	{
		"id": "RU",
		"name": "Rusia (+7)"
	},
	{
		"id": "SH",
		"name": "Saint Helena (+290)"
	},
	{
		"id": "PM",
		"name": "Saint Pierre And Miquelon"
	},
	{
		"id": "AS",
		"name": "Samoa Americana"
	},
	{
		"id": "WS",
		"name": "Samoa del Oeste"
	},
	{
		"id": "KN",
		"name": "San Cristóbal y Nieves (+1869)"
	},
	{
		"id": "SX",
		"name": "San Martín"
	},
	{
		"id": "LC",
		"name": "Santa Lucía"
	},
	{
		"id": "ST",
		"name": "Santo Tomé y Príncipe (+239)"
	},
	{
		"id": "VC",
		"name": "San Vicente y las Granadinas"
	},
	{
		"id": "SN",
		"name": "Senegal (+221)"
	},
	{
		"id": "RS",
		"name": "Serbia"
	},
	{
		"id": "SC",
		"name": "Seychelles (+248)"
	},
	{
		"id": "SL",
		"name": "Sierra Leona (+232)"
	},
	{
		"id": "SG",
		"name": "Singapur (+65)"
	},
	{
		"id": "SY",
		"name": "Siria"
	},
	{
		"id": "SO",
		"name": "Somalia (+252)"
	},
	{
		"id": "LK",
		"name": "Sri Lanka (+94)"
	},
	{
		"id": "SZ",
		"name": "Suazilandia (+268)"
	},
	{
		"id": "ZA",
		"name": "Sudáfrica (+27)"
	},
	{
		"id": "SD",
		"name": "Sudán (+249)"
	},
	{
		"id": "SS",
		"name": "Sudán del Sur"
	},
	{
		"id": "SE",
		"name": "Suecia (+46)"
	},
	{
		"id": "CH",
		"name": "Suiza (+41)"
	},
	{
		"id": "SR",
		"name": "Surinam (+597)"
	},
	{
		"id": "TH",
		"name": "Tailandia (+66)"
	},
	{
		"id": "TW",
		"name": "Taiwán (+886)"
	},
	{
		"id": "TZ",
		"name": "Tanzania"
	},
	{
		"id": "TJ",
		"name": "Tayikistán (+7)"
	},
	{
		"id": "TG",
		"name": "Togo (+228)"
	},
	{
		"id": "TK",
		"name": "Tokelau"
	},
	{
		"id": "TO",
		"name": "Tonga (+676)"
	},
	{
		"id": "TT",
		"name": "Trinidad y Tobago (+1868)"
	},
	{
		"id": "TN",
		"name": "Túnez (+216)"
	},
	{
		"id": "TM",
		"name": "Turkmenistán (+7)"
	},
	{
		"id": "TR",
		"name": "Turquía (+90)"
	},
	{
		"id": "TV",
		"name": "Tuvalu (+688)"
	},
	{
		"id": "UA",
		"name": "Ucrania (+380)"
	},
	{
		"id": "UG",
		"name": "Uganda (+256)"
	},
	{
		"id": "UY",
		"name": "Uruguay (+598)"
	},
	{
		"id": "UZ",
		"name": "Uzbekistán (+7)"
	},
	{
		"id": "VU",
		"name": "Vanuatu (+678)"
	},
	{
		"id": "VE",
		"name": "Venezuela (+58)"
	},
	{
		"id": "VN",
		"name": "Vietnam (+84)"
	},
	{
		"id": "WF",
		"name": "Wallis y Futuna (+681)"
	},
	{
		"id": "YE",
		"name": "Yemen (+969)"
	},
	{
		"id": "DJ",
		"name": "Yibuti (+253)"
	},
	{
		"id": "YU",
		"name": "Yugoslavia"
	},
	{
		"id": "ZM",
		"name": "Zambia (+260)"
	},
	{
		"id": "ZW",
		"name": "Zimbabue (+263)"
	}
];

export const TRAVELERS_COUNTRIES_CONTACT_EN = [
	{
		"id": "AF",
		"name": "Afghanistan"
	},
	{
		"id": "AL",
		"name": "Albania"
	},
	{
		"id": "DZ",
		"name": "Algeria (+213)"
	},
	{
		"id": "AS",
		"name": "American Samoa"
	},
	{
		"id": "AD",
		"name": "Andorra (+376)"
	},
	{
		"id": "AO",
		"name": "Angola (+244)"
	},
	{
		"id": "AI",
		"name": "Anguilla (+1264)"
	},
	{
		"id": "AG",
		"name": "Antigua and Barbuda (+1268)"
	},
	{
		"id": "AR",
		"name": "Argentina (+54)"
	},
	{
		"id": "AM",
		"name": "Armenia (+374)"
	},
	{
		"id": "AW",
		"name": "Aruba (+297)"
	},
	{
		"id": "AU",
		"name": "Australia (+61)"
	},
	{
		"id": "AT",
		"name": "Austria (+43)"
	},
	{
		"id": "AZ",
		"name": "Azerbaijan (+994)"
	},
	{
		"id": "BS",
		"name": "Bahamas (+1242)"
	},
	{
		"id": "BH",
		"name": "Bahrain (+973)"
	},
	{
		"id": "BD",
		"name": "Bangladesh (+880)"
	},
	{
		"id": "BB",
		"name": "Barbados (+1246)"
	},
	{
		"id": "BY",
		"name": "Belarus (+375)"
	},
	{
		"id": "BE",
		"name": "Belgium (+32)"
	},
	{
		"id": "BZ",
		"name": "Belize (+501)"
	},
	{
		"id": "BJ",
		"name": "Benin (+229)"
	},
	{
		"id": "BM",
		"name": "Bermuda (+1441)"
	},
	{
		"id": "BO",
		"name": "Bolivia (+591)"
	},
	{
		"id": "BQ",
		"name": "Bonaire, Saint Eustatius and Saba"
	},
	{
		"id": "BA",
		"name": "Bosnia-Herzegovina (+387)"
	},
	{
		"id": "BW",
		"name": "Botswana (+267)"
	},
	{
		"id": "BR",
		"name": "Brazil (+55)"
	},
	{
		"id": "VG",
		"name": "British Virgin Islands (+84)"
	},
	{
		"id": "BN",
		"name": "Brunei Darussalam (+673)"
	},
	{
		"id": "BG",
		"name": "Bulgaria (+359)"
	},
	{
		"id": "BF",
		"name": "Burkina Faso (+226)"
	},
	{
		"id": "BI",
		"name": "Burundi (+257)"
	},
	{
		"id": "KH",
		"name": "Cambodia (+855)"
	},
	{
		"id": "CM",
		"name": "Cameroon (+237)"
	},
	{
		"id": "CA",
		"name": "Canada (+1)"
	},
	{
		"id": "CV",
		"name": "Cape Verde (+238)"
	},
	{
		"id": "KY",
		"name": "Cayman Islands (+1345)"
	},
	{
		"id": "CF",
		"name": "Central African Republic (+236)"
	},
	{
		"id": "TD",
		"name": "Chad"
	},
	{
		"id": "CL",
		"name": "Chile (+56)"
	},
	{
		"id": "CN",
		"name": "China (+86)"
	},
	{
		"id": "CO",
		"name": "Colombia (+57)"
	},
	{
		"id": "KM",
		"name": "Comoros (+269)"
	},
	{
		"id": "CG",
		"name": "Congo (+242)"
	},
	{
		"id": "CD",
		"name": "Congo"
	},
	{
		"id": "CK",
		"name": "Cook Islands (+682)"
	},
	{
		"id": "CR",
		"name": "Costa Rica (+506)"
	},
	{
		"id": "HR",
		"name": "Croatia (+385)"
	},
	{
		"id": "CU",
		"name": "Cuba (+53)"
	},
	{
		"id": "CW",
		"name": "Curazao"
	},
	{
		"id": "CY",
		"name": "Cyprus (+90392)"
	},
	{
		"id": "CZ",
		"name": "Czech Republic (+42)"
	},
	{
		"id": "DK",
		"name": "Denmark (+45)"
	},
	{
		"id": "DJ",
		"name": "Djibouti (+253)"
	},
	{
		"id": "DO",
		"name": "Dominican Republic (+1809)"
	},
	{
		"id": "EC",
		"name": "Ecuador (+593)"
	},
	{
		"id": "EG",
		"name": "Egypt (+20)"
	},
	{
		"id": "SV",
		"name": "El Salvador (+503)"
	},
	{
		"id": "GQ",
		"name": "Equatorial Guinea (+240)"
	},
	{
		"id": "ER",
		"name": "Eritrea (+291)"
	},
	{
		"id": "EE",
		"name": "Estonia (+372)"
	},
	{
		"id": "ET",
		"name": "Ethiopia (+251)"
	},
	{
		"id": "FK",
		"name": "Falkland Islands (+500)"
	},
	{
		"id": "FO",
		"name": "Faroe Islands (+298)"
	},
	{
		"id": "FJ",
		"name": "Fiji (+679)"
	},
	{
		"id": "FI",
		"name": "Finland (+358)"
	},
	{
		"id": "FR",
		"name": "France (+33)"
	},
	{
		"id": "GF",
		"name": "French Guiana (+594)"
	},
	{
		"id": "PF",
		"name": "French Polynesia (+689)"
	},
	{
		"id": "GA",
		"name": "Gabon (+241)"
	},
	{
		"id": "GM",
		"name": "Gambia (+220)"
	},
	{
		"id": "GE",
		"name": "Georgia (+7880)"
	},
	{
		"id": "DE",
		"name": "Germany (+49)"
	},
	{
		"id": "GH",
		"name": "Ghana (+233)"
	},
	{
		"id": "GI",
		"name": "Gibraltar (+350)"
	},
	{
		"id": "GR",
		"name": "Greece (+30)"
	},
	{
		"id": "GD",
		"name": "Grenada (+1473)"
	},
	{
		"id": "GP",
		"name": "Guadeloupe (+590)"
	},
	{
		"id": "GU",
		"name": "Guam (+671)"
	},
	{
		"id": "GT",
		"name": "Guatemala (+502)"
	},
	{
		"id": "GN",
		"name": "Guinea (+224)"
	},
	{
		"id": "GW",
		"name": "Guinea-Bissau (+245)"
	},
	{
		"id": "GY",
		"name": "Guyana (+592)"
	},
	{
		"id": "HT",
		"name": "Haiti (+509)"
	},
	{
		"id": "HN",
		"name": "Honduras (+504)"
	},
	{
		"id": "HK",
		"name": "Hong Kong (+852)"
	},
	{
		"id": "HU",
		"name": "Hungary (+36)"
	},
	{
		"id": "IS",
		"name": "Iceland (+354)"
	},
	{
		"id": "IN",
		"name": "India (+91)"
	},
	{
		"id": "ID",
		"name": "Indonesia (+62)"
	},
	{
		"id": "IR",
		"name": "Iran (+98)"
	},
	{
		"id": "IQ",
		"name": "Iraq (+964)"
	},
	{
		"id": "IE",
		"name": "Ireland (+353)"
	},
	{
		"id": "IL",
		"name": "Israel (+972)"
	},
	{
		"id": "IT",
		"name": "Italy (+39)"
	},
	{
		"id": "CI",
		"name": "Ivory Coast, Cote d Ivoire"
	},
	{
		"id": "JM",
		"name": "Jamaica (+1876)"
	},
	{
		"id": "JP",
		"name": "Japan (+81)"
	},
	{
		"id": "JO",
		"name": "Jordan (+962)"
	},
	{
		"id": "KZ",
		"name": "Kazakhstan (+7)"
	},
	{
		"id": "KE",
		"name": "Kenya (+254)"
	},
	{
		"id": "KW",
		"name": "Kuwait (+965)"
	},
	{
		"id": "KG",
		"name": "Kyrgyzstan (+996)"
	},
	{
		"id": "LA",
		"name": "Laos (+856)"
	},
	{
		"id": "LV",
		"name": "Latvia (+371)"
	},
	{
		"id": "LB",
		"name": "Lebanon (+961)"
	},
	{
		"id": "LS",
		"name": "Lesotho (+266)"
	},
	{
		"id": "LR",
		"name": "Liberia (+231)"
	},
	{
		"id": "LY",
		"name": "Libya (+218)"
	},
	{
		"id": "LT",
		"name": "Lithuania (+370)"
	},
	{
		"id": "LU",
		"name": "Luxembourg (+352)"
	},
	{
		"id": "MO",
		"name": "Macau (+853)"
	},
	{
		"id": "MK",
		"name": "Macedonia (+389)"
	},
	{
		"id": "MG",
		"name": "Madagascar (+261)"
	},
	{
		"id": "MW",
		"name": "Malawi (+265)"
	},
	{
		"id": "MY",
		"name": "Malaysia (+60)"
	},
	{
		"id": "MV",
		"name": "Maldives (+960)"
	},
	{
		"id": "ML",
		"name": "Mali (+223)"
	},
	{
		"id": "MT",
		"name": "Malta (+356)"
	},
	{
		"id": "MP",
		"name": "Mariana Islands"
	},
	{
		"id": "MH",
		"name": "Marshall Islands (+692)"
	},
	{
		"id": "MQ",
		"name": "Martinique (+596)"
	},
	{
		"id": "MR",
		"name": "Mauritania (+222)"
	},
	{
		"id": "MU",
		"name": "Mauritius"
	},
	{
		"id": "MX",
		"name": "Mexico (+52)"
	},
	{
		"id": "FM",
		"name": "Micronesia (+691)"
	},
	{
		"id": "MD",
		"name": "Moldova (+373)"
	},
	{
		"id": "MC",
		"name": "Monaco (+377)"
	},
	{
		"id": "MN",
		"name": "Mongolia (+976)"
	},
	{
		"id": "ME",
		"name": "Montenegro"
	},
	{
		"id": "MS",
		"name": "Montserrat (+1664)"
	},
	{
		"id": "MA",
		"name": "Morocco (+212)"
	},
	{
		"id": "MZ",
		"name": "Mozambique (+258)"
	},
	{
		"id": "MM",
		"name": "Myanmar"
	},
	{
		"id": "NA",
		"name": "Namibia (+264)"
	},
	{
		"id": "NR",
		"name": "Nauru (+674)"
	},
	{
		"id": "NP",
		"name": "Nepal (+977)"
	},
	{
		"id": "NL",
		"name": "Netherlands (+31)"
	},
	{
		"id": "AN",
		"name": "Netherlands Antilles"
	},
	{
		"id": "NC",
		"name": "New Caledonia (+687)"
	},
	{
		"id": "NZ",
		"name": "New Zealand (+64)"
	},
	{
		"id": "NI",
		"name": "Nicaragua (+505)"
	},
	{
		"id": "NE",
		"name": "Niger (+227)"
	},
	{
		"id": "NG",
		"name": "Nigeria (+234)"
	},
	{
		"id": "NU",
		"name": "Niue (+683)"
	},
	{
		"id": "NF",
		"name": "Norfolk Island (+672)"
	},
	{
		"id": "KP",
		"name": "North Korea (+850)"
	},
	{
		"id": "NO",
		"name": "Norway (+47)"
	},
	{
		"id": "OM",
		"name": "Oman (+968)"
	},
	{
		"id": "PK",
		"name": "Pakistan"
	},
	{
		"id": "PW",
		"name": "Palau Islands (+680)"
	},
	{
		"id": "PA",
		"name": "Panama (+507)"
	},
	{
		"id": "PG",
		"name": "Papua New Guinea (+675)"
	},
	{
		"id": "PY",
		"name": "Paraguay (+595)"
	},
	{
		"id": "PE",
		"name": "Peru (+51)"
	},
	{
		"id": "PH",
		"name": "Philippines (+63)"
	},
	{
		"id": "PL",
		"name": "Poland (+48)"
	},
	{
		"id": "PT",
		"name": "Portugal (+351)"
	},
	{
		"id": "PR",
		"name": "Puerto Rico (+1787)"
	},
	{
		"id": "QA",
		"name": "Qatar (+974)"
	},
	{
		"id": "RE",
		"name": "Réunion (+262)"
	},
	{
		"id": "RO",
		"name": "Romania (+40)"
	},
	{
		"id": "RU",
		"name": "Russia (+7)"
	},
	{
		"id": "RW",
		"name": "Rwanda (+250)"
	},
	{
		"id": "SH",
		"name": "Saint Helena (+290)"
	},
	{
		"id": "KN",
		"name": "Saint Kitts and Nevis (+1869)"
	},
	{
		"id": "LC",
		"name": "Saint Lucia"
	},
	{
		"id": "SX",
		"name": "Saint Maarten"
	},
	{
		"id": "PM",
		"name": "Saint Pierre And Miquelon"
	},
	{
		"id": "VC",
		"name": "Saint Vincent and the Grenadines"
	},
	{
		"id": "ST",
		"name": "São Tomé and Príncipe (+239)"
	},
	{
		"id": "SA",
		"name": "Saudi Arabia (+966)"
	},
	{
		"id": "SN",
		"name": "Senegal (+221)"
	},
	{
		"id": "RS",
		"name": "Serbia"
	},
	{
		"id": "SC",
		"name": "Seychelles (+248)"
	},
	{
		"id": "SL",
		"name": "Sierra Leone (+232)"
	},
	{
		"id": "SG",
		"name": "Singapore (+65)"
	},
	{
		"id": "SK",
		"name": "Slovakia (+421)"
	},
	{
		"id": "SI",
		"name": "Slovenia (+386)"
	},
	{
		"id": "SB",
		"name": "Solomon Islands (+677)"
	},
	{
		"id": "SO",
		"name": "Somalia (+252)"
	},
	{
		"id": "ZA",
		"name": "South Africa (+27)"
	},
	{
		"id": "KR",
		"name": "South Korea (+82)"
	},
	{
		"id": "SS",
		"name": "South Sudan"
	},
	{
		"id": "ES",
		"name": "Spain (+34)"
	},
	{
		"id": "LK",
		"name": "Sri Lanka (+94)"
	},
	{
		"id": "SD",
		"name": "Sudan (+249)"
	},
	{
		"id": "SR",
		"name": "Suriname (+597)"
	},
	{
		"id": "SZ",
		"name": "Swaziland (+268)"
	},
	{
		"id": "SE",
		"name": "Sweden (+46)"
	},
	{
		"id": "CH",
		"name": "Switzerland (+41)"
	},
	{
		"id": "SY",
		"name": "Syria"
	},
	{
		"id": "TW",
		"name": "Taiwan (+886)"
	},
	{
		"id": "TJ",
		"name": "Tajikistan (+7)"
	},
	{
		"id": "TZ",
		"name": "Tanzania"
	},
	{
		"id": "TH",
		"name": "Thailand (+66)"
	},
	{
		"id": "TG",
		"name": "Togo (+228)"
	},
	{
		"id": "TK",
		"name": "Tokelau"
	},
	{
		"id": "TO",
		"name": "Tonga (+676)"
	},
	{
		"id": "TT",
		"name": "Trinidad and Tobago (+1868)"
	},
	{
		"id": "TN",
		"name": "Tunisia (+216)"
	},
	{
		"id": "TR",
		"name": "Turkey (+90)"
	},
	{
		"id": "TM",
		"name": "Turkmenistan (+7)"
	},
	{
		"id": "TC",
		"name": "Turks and Caicos Islands (+1649)"
	},
	{
		"id": "TV",
		"name": "Tuvalu (+688)"
	},
	{
		"id": "UG",
		"name": "Uganda (+256)"
	},
	{
		"id": "UA",
		"name": "Ukraine (+380)"
	},
	{
		"id": "AE",
		"name": "United Arab Emirates (+971)"
	},
	{
		"id": "GB",
		"name": "United Kingdom (+44)"
	},
	{
		"id": "US",
		"name": "United States   (+1)"
	},
	{
		"id": "UY",
		"name": "Uruguay (+598)"
	},
	{
		"id": "VI",
		"name": "US Virgin Islands (+84)"
	},
	{
		"id": "UZ",
		"name": "Uzbekistan (+7)"
	},
	{
		"id": "VU",
		"name": "Vanuatu (+678)"
	},
	{
		"id": "VE",
		"name": "Venezuela (+58)"
	},
	{
		"id": "VN",
		"name": "Vietnam (+84)"
	},
	{
		"id": "WF",
		"name": "Wallis and Futuna (+681)"
	},
	{
		"id": "WS",
		"name": "Western Samoa"
	},
	{
		"id": "YE",
		"name": "Yemen (+969)"
	},
	{
		"id": "YU",
		"name": "Yugoslavia"
	},
	{
		"id": "ZM",
		"name": "Zambia (+260)"
	},
	{
		"id": "ZW",
		"name": "Zimbabwe (+263)"
	}
];

export const NOT_SESSION_ERROR = {
	status: 401,
	message: '401-403 Not logged in. It is necessary to start session.',
};
  
export const GENERAL_ERROR = {
	status: 500,
	message: 'The service is unavailable temporary',
};

// OAuth2 Properties
export const oauth2LMLogin = {
	authorizeUrl: endpoints['oauth2Authorization'],
	clientID: 'lm_website',	
	loginUrl: endpoints['oauth2Login'],
	redirectUrl: `${ envHost }oauth-signin`,
	scopes: ['read']
};
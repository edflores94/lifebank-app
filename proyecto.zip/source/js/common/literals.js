const literals = {
  LANGUAGE_EN: {
    en: 'English',
    es: 'Inglés',
  },
  LANGUAGE_ES: {
    en: 'Spanish',
    es: 'Español',
  },
  menus: {
    MENU_ITEMS: {
      en: ['#','Credit Cards','Transfers', 'Loans', 'Consults'],
      es: ['#','Tarjetas de Crédito', 'Transferencias','Préstamos', 'Consultas']
    },
    MENU_ITEMS2: {
      en: ['#','Credit Cards','Transfers', 'Loans'],
      es: ['#','Tarjetas de Crédito', 'Transferencias','Préstamos']
    }
  }
};

export default literals;

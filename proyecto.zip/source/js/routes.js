import React, { Component } from 'react';
import { Router, Route, IndexRoute, browserHistory } from 'react-router';
import App from 'views/App';
import NotFound from 'views/NotFound/';
import Home from 'views/Home/index/';


export default class Routes extends Component {
  render() {
    return (
      <Router history={ browserHistory }>
        <Route path={ publicPath } component={ App }>
          <IndexRoute component={ Home } />
          <Route path='*' component={ NotFound } />
        </Route>
      </Router>
    );
  }
}

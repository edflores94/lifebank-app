
export const FINISH_INITIAL_LOADING = 'FINISH_INITIAL_LOADING';
export const SET_CONTEXTUALIZATION_MENU = 'SET_CONTEXTUALIZATION_MENU';

export function finishInitialLoading() {
  return {
    type: FINISH_INITIAL_LOADING
  };
}

export function setContextualizationMenu(data) {
  return {
    type: SET_CONTEXTUALIZATION_MENU,
    data
  }
}

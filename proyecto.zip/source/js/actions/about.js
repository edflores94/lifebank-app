import api from 'api/about';
import aboutLifemilesTransformer from 'transformers/about';
import {NOT_SESSION_ERROR,GENERAL_ERROR} from 'common/constants';

export const GET_ABOUT_LIFEMILES_ACTION_START = 'GET_ABOUT_LIFEMILES_ACTION_START';
export const GET_ABOUT_LIFEMILES_ACTION_ERROR = 'GET_ABOUT_LIFEMILES_ACTION_ERROR';
export const GET_ABOUT_LIFEMILES_ACTION_SUCCESS = 'GET_ABOUT_LIFEMILES_ACTION_SUCCESS';

export const TRANSFORMATION_ERROR = {
  message: 'Data transformation failed - data does not conform to validators.',
};

function getAboutLifemilesActionStart() {
  return {
    type: GET_ABOUT_LIFEMILES_ACTION_START,
  };
}

function getAboutLifemilesActionError(error) {
  return {
    type: GET_ABOUT_LIFEMILES_ACTION_ERROR,
    error,
  };
}

function getAboutLifemilesActionSuccess(data) {
  return {
    type: GET_ABOUT_LIFEMILES_ACTION_SUCCESS,
    data,
  };
}

export function getAboutLifemilesAsync(country, language, currency) {
  return function (dispatch) {
    dispatch(getAboutLifemilesActionStart());
    api.getAboutLifemilesAsync(country, language, currency)
    .then(response => {
      const statusReq = response.status;
      if(statusReq == 200 || statusReq == 202) {
        return response.json();
      }
      else {
        if (statusReq == 401 || statusReq == 403) {
          dispatch(getAboutLifemilesActionError(NOT_SESSION_ERROR));
          return false;
        }
        else {
          dispatch(getAboutLifemilesActionError(GENERAL_ERROR));
          return false;
        }
      }
    })
      .then(data => dispatch(() => {
        const trasformedData = aboutLifemilesTransformer.transformAboutLifemilesResponse(data);
        if (trasformedData) {
          dispatch(getAboutLifemilesActionSuccess(trasformedData));
        } else {
          dispatch(getAboutLifemilesActionError(TRANSFORMATION_ERROR));
        }
      }))
      .catch(error => dispatch(getAboutLifemilesActionError(error)));
  };
}

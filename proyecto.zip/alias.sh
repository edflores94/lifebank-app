#! /bin/bash

alias dockerx="docker -H=192.168.66.89:2375"
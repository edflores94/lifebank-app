import React from 'react';
import Menu from '../../components/Menu/Menu';
import './NotFound.scss';
import '../../../node_modules/bootstrap/scss/bootstrap.scss';
import notFoundUrl from '../../images/not-found.png';

export default class NotFound extends React.Component {

  render() {

    return (
      <div>
        <Menu />
        <div className="form-row">
          <div className="col-md-4 offset-md-4 mb-3">
            <div className="wrapper">
              <div className="center">
                <img className="card-img-top" src={notFoundUrl} alt="Imagen" style={{ height: 200 + 'px', width: 200 + 'px' }} />
                <h1 className="card-title">404</h1>
                <h5 className="card-title">Página no encontrada</h5>
              </div>
            </div>

            <p className="card-text">Lo sentimos, no pudimos encontrar la pagina que solicitaste.</p>
            <div className="center">
              <a className="btn btn-primary" href='/'>Volver a inicio</a>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

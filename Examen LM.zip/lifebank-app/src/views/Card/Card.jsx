import React from 'react';
import PropTypes from 'prop-types';
import '../../../node_modules/bootstrap/scss/bootstrap.scss';
import './Card.scss';
import Menu from '../../components/Menu/MenuSigned';
import Footer from '../../components/Footer/Footer';

export default class Card extends React.Component {
  static propTypes = {
    dispatch: PropTypes.func
  }

  constructor(props) {
    super(props);

    this.state = {
      data: []
    }
  }

  componentDidMount() {
    fetch('http://private-12729-proyect1.apiary-mock.com/lifebank/cards')
      .then(res => res.json())
      .then((data) => {
        this.setState({ data: data })
      })
      .catch(error => console.log(error));
  }

  render() {
    const {
      data
    } = this.state;

    return (
      <div>
        <Menu />
        <div class="jumbotron" style={{ marginBottom: 0 }}>
          <div style={{ textAlign: 'center' }}>
            <h2 class="display-4">Consultar tarjetas</h2>
            <hr class="my-4" />
          </div>
          

          <table class="table table-bordered" >
            <thead>
              <tr style={{backgroundColor:'#17a2b8'}}>
                <th scope="col">#</th>
                <th scope="col">Número Tarjeta</th>
                <th scope="col">Titular</th>
                <th scope="col">Moneda</th>
                <th scope="col">Saldos</th>
                <th scope="col">Estado</th>
              </tr>
            </thead>
            <tbody>
              {data && data.tarjetas && data.tarjetas.map((item, key) =>
                <tr>
                  <th>{key + 1}</th>
                  <td>{item.tarjeta}</td>
                  <td>{item.nombre}</td>
                  <td>{item.moneda}</td>
                  <td>{item.saldos}</td>
                  <td>{item.estado}</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
        <Footer />
      </div>
    );
  }
}
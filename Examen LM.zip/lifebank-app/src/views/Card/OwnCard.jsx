import React from 'react';
import '../../../node_modules/bootstrap/scss/bootstrap.scss';
import './OwnCard.scss';
import Menu from '../../components/Menu/MenuSigned';
import Footer from '../../components/Footer/Footer';

export default class OwnCard extends React.Component {

  render() {

    return (
      <div>
        <Menu />
        <div class="jumbotron" style={{ marginBottom: 0 }}>
          <div style={{ textAlign: 'center' }}>
            <h2 class="display-4">Pago tarjetas propias</h2>
            <hr class="my-4" />
          </div>

          <form>
            <div className="row offset-md-3">
              <div className="col-md-4">
                <div class="form-group">
                  <label>Cuenta a debitar</label>
                  <select class="form-control">
                    <option>55343403493</option>
                    <option>45342342344</option>
                    <option>60495304095</option>
                  </select>
                </div>
              </div>

              <div className="col-md-4">
                <div class="form-group">
                  <label>Monto</label>
                  <input type="text" className="form-control" placeholder="Ingrese un monto" required />
                </div>
              </div>
            </div>

            <div className="row offset-md-3">
              <div className="col-md-4">
                <div class="form-group">
                  <label>Número de tarjeta</label>
                  <select class="form-control">
                    <option>450000000343</option>
                    <option>450000000054</option>
                  </select>
                </div>
              </div>
              <div className="col-md-4">
                <div class="form-group">
                  <label>Moneda</label>
                  <select class="form-control">
                    <option>USD</option>
                    <option>EUR</option>
                  </select>
                </div>
              </div>
            </div>

            

            <div className="row offset-md-3">
              <div className="col-md-4">
                <div class="form-group">
                  <button className="btn btn-primary" style={{marginRight:'1rem'}}>Procesar</button>
                  <button className="btn btn-secondary">Cancelar</button>
                </div>
              </div>
            </div>

          </form>


        </div>
        <Footer />
      </div>
    );
  }
}
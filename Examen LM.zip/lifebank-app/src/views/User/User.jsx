import React from 'react';
import PropTypes from 'prop-types';
import '../../../node_modules/bootstrap/scss/bootstrap.scss';
//import { getUsersAsync } from '../../actions/user';
import './User.scss';
import Menu from '../../components/Menu/MenuSigned';
import Footer from '../../components/Footer/Footer';
import iconLB from '../../images/lifebank-logo.png';

export default class User extends React.Component {
  static propTypes = {
    dispatch: PropTypes.func
  }

  constructor(props) {
    super(props);

    this.state = {
      data: []
    }
  }

  componentDidMount() {
    fetch('http://private-12729-proyect1.apiary-mock.com/lifebank/users')
      .then(res => res.json())
      .then((data) => {
        this.setState({ data: data })
      })
      .catch(error => console.log(error));
  }

  render() {
    const {
      data
    } = this.state;

    return (
      <div>
        <Menu />
        <div class="jumbotron" style={{ marginBottom: 0 }}>
          <div style={{ textAlign: 'center' }}>
            <h2 class="display-4">Mantenimiento de beneficiarios</h2>
            <hr class="my-4" />
          </div>
          <div className='pad-bottom'>
            <button className="btn btn-success">Nuevo beneficiario</button>
          </div>

          <table class="table table-bordered" >
            <thead>
              <tr style={{backgroundColor:'#17a2b8'}}>
                <th scope="col">#</th>
                <th scope="col">Nombre</th>
                <th scope="col">Número de Producto</th>
                <th scope="col">Tipo de servicio</th>
                <th scope="col">Correo</th>
                <th scope="col" colSpan="2">Acciones</th>
              </tr>
            </thead>
            <tbody>
              {data && data.beneficiarios && data.beneficiarios.map((item, key) =>
                <tr>
                  <th>{key + 1}</th>
                  <td>{item.nombre}</td>
                  <td>{item.numProducto}</td>
                  <td>{item.servicio}</td>
                  <td>{item.correo}</td>
                  <td style={{ textAlign: 'center' }}><button className="btn btn-primary" >Editar</button></td>
                  <td style={{ textAlign: 'center' }}><button className="btn btn-danger" >Eliminar</button></td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
        <Footer />
      </div>
    );
  }
}
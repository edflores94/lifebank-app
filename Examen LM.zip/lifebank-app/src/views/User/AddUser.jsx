import React from 'react';
import '../../../node_modules/bootstrap/scss/bootstrap.scss';
import './AddUser.scss';
import Menu from '../../components/Menu/MenuSigned';
import Footer from '../../components/Footer/Footer';
import Modal from '../../components/Modal/Modal';

export default class AddUser extends React.Component {

  render() {

    return (
      <div>
        <Menu />
        <div class="jumbotron" style={{ marginBottom: 0 }}>
          <div style={{ textAlign: 'center' }}>
            <h2 class="display-4">Agregar beneficiarios</h2>
            <hr class="my-4" />
          </div>

          <form>
            <div className="row offset-md-4">
              <div className="col-md-6">
                <div class="form-group">
                  <label>Servicio</label>
                  <select class="form-control">
                    <option>Transferencias a terceros</option>
                    <option>Pago préstamos a terceros</option>
                    <option>Pago tarjetas a terceros</option>
                  </select>
                </div>
              </div>
            </div>

            <div className="row offset-md-4">
              <div className="col-md-6">
                <div class="form-group">
                  <label>Nombre beneficiario</label>
                  <input type="text" className="form-control" placeholder="Ingrese el nombre del beneficiario" required />
                </div>
              </div>
            </div>

            <div className="row offset-md-4">
              <div className="col-md-6">
                <div class="form-group">
                  <label>Email beneficiario</label>
                  <input type="text" className="form-control" placeholder="Ingrese el correo del beneficiario" required />
                </div>
              </div>
            </div>

            <div className="row offset-md-4">
              <div className="col-md-6">
                <div class="form-group">
                  <button className="btn btn-primary" style={{ marginRight: '1rem' }}>Procesar</button>
                  <button className="btn btn-secondary">Cancelar</button>
                </div>
              </div>
            </div>
          </form>

        </div>
        <Footer />
      </div>
    );
  }
}
import React from 'react';
import '../../../node_modules/bootstrap/scss/bootstrap.scss';
import './ChangeUser.scss';
import Menu from '../../components/Menu/MenuSigned';
import Footer from '../../components/Footer/Footer';

export default class ChangeUser extends React.Component {

  render() {

    return (
      <div>
        <Menu />
        <div class="jumbotron" style={{ marginBottom: 0 }}>
          <div style={{ textAlign: 'center' }}>
            <h2 class="display-4">Cambiar usuario</h2>
            <hr class="my-4" />
          </div>

          <form>
            <div className="row offset-md-4">
              <div className="col-md-6">
                <div class="form-group">
                <label>Usuario actual</label>
                    <input type="text" className="form-control" placeholder="Ingrese su usuario actual" required />
                </div>
              </div>
            </div>

            <div className="row offset-md-4">
              <div className="col-md-6">
                <div class="form-group">
                <label>Nuevo usuario</label>
                    <input type="text" className="form-control" placeholder="Ingrese su nuevo usuario" required />
                </div>
              </div>
            </div>
            <div className="row offset-md-4">
              <div className="col-md-6">
                <div class="form-group">
                  <button className="btn btn-primary" style={{ marginRight: '1rem' }}>Cambiar</button>
                  <button className="btn btn-secondary">Cancelar</button>
                </div>
              </div>
            </div>
          </form>

        </div>
        <Footer />
      </div>
    );
  }
}

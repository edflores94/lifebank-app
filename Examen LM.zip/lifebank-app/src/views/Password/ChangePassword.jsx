import React from 'react';
import '../../../node_modules/bootstrap/scss/bootstrap.scss';
import './ChangePassword.scss';
import Menu from '../../components/Menu/MenuSigned';
import Footer from '../../components/Footer/Footer';

export default class ChangePassword extends React.Component {

  render() {

    return (
      <div>
        <Menu />
        <div class="jumbotron" style={{ marginBottom: 0 }}>
          <div style={{ textAlign: 'center' }}>
            <h2 class="display-4">Cambiar contraseña</h2>
            <hr class="my-4" />
          </div>

          <form>
            <div className="row offset-md-4">
              <div className="col-md-6">
                <div class="form-group">
                <label>Contraseña actual</label>
                    <input type="password" className="form-control" placeholder="Ingrese su contraseña actual" required />
                </div>
              </div>
            </div>

            <div className="row offset-md-4">
              <div className="col-md-6">
                <div class="form-group">
                <label>Nueva contraseña</label>
                    <input type="password" className="form-control" placeholder="Ingrese su nueva contraseña" required />
                </div>
              </div>
            </div>

            <div className="row offset-md-4">
              <div className="col-md-6">
                <div class="form-group">
                <label>Repetir contraseña</label>
                    <input type="password" className="form-control" placeholder="Repita la nueva contraseña" required />
                </div>
              </div>
            </div>

            <div className="row offset-md-4">
              <div className="col-md-6">
                <div class="form-group">
                  <button className="btn btn-primary" style={{ marginRight: '1rem' }}>Cambiar</button>
                  <button className="btn btn-secondary">Cancelar</button>
                </div>
              </div>
            </div>
          </form>

        </div>
        <Footer />
      </div>
    );
  }
}

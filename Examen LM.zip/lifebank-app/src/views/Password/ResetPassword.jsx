import React from 'react';
import '../../../node_modules/bootstrap/scss/bootstrap.scss';
import './ResetPassword.scss';
import iconLogin from '../../images/lifebank-logo.png';

export default class ResetPassword extends React.Component {

  render() {

    return (
      <div>
        <div className='wrapperReset'>
        </div>
        <div class="jumbotron" style={{ marginBottom: 0 }}>
          <div style={{ textAlign: 'center' }}>
            <h2 class="display-4">Recuperar contraseña</h2>
          </div>

          <div style={{ textAlign: 'center' }}>
            <img className="card-img-top" src={iconLogin} alt="Imagen" style={{ height: 50 + 'px', width: 'auto' }} />
          </div>

          <form>
            <div className="row offset-md-4">
              <div className="col-md-6">
                <div class="form-group">
                  <label>Email</label>
                  <input type="text" id="username" className="form-control" placeholder="Ingrese su correo electrónico" required />
                </div>
              </div>
            </div>


          </form>
          <div className="row offset-md-4">
            <div className="col-md-6">
              <div class="form-group">
                <button class="btn btn-primary" style={{ marginRight: '1rem' }} onClick={() => { this.sendPass() }}>Enviar</button>
                <a class="btn btn-secondary" href='/login'>Volver</a>
              </div>
            </div>
          </div>
        </div>
        <div className='wrapperReset'>
        </div>
      </div>

    );
  }
}
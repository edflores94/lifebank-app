import React from 'react';
import '../../../node_modules/bootstrap/scss/bootstrap.scss';
import Menu from '../../components/Menu/MenuSigned';
import Carousel from '../../components/Carousel/Carousel';
import Footer from '../../components/Footer/Footer';
import iconLB from '../../images/lifebank-logo.png';

export default class WelcomeSigned extends React.Component {

  render() {
    return (
      <div>
        <Menu />
        <div class="jumbotron">
        <div style={{textAlign:'center'}}>
        <h1 class="display-4">Bienvenido a LifeBank</h1>
          <p class="lead">Te damos la bienvenida a tu plataforma digital <b>LifeBank</b></p>
          <img src={iconLB} alt="logo LifeBank" />
          <hr class="my-4" />
          <p>Nuestra plataforma te permite gestionar los productos bancarios que posees con nuestra institución,
            en donde podrás: realizar el pago de tu tarjeta de crédito o débito, solicitar préstamos, 
            realizar transacciones a cuentas propias y de terceros, entre otras opciones.</p>
        </div>
        <Carousel/>
        </div>
        <Footer />
      </div>
    );
  }
}
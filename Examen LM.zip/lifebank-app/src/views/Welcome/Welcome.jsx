import React from 'react';
import '../../../node_modules/bootstrap/scss/bootstrap.scss';
import Menu from '../../components/Menu/Menu';
import Carousel from '../../components/Carousel/Carousel';
import Footer from '../../components/Footer/Footer';

export default class WelcomeSigned extends React.Component {
//style={{background:'#5EBEDF'}}
  render() {
    return (
      <div>
      <Menu/>
      <Carousel/>
      <Footer/>
      </div>
    );
  }
}
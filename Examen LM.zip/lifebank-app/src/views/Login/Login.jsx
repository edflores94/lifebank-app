import React from 'react';
import { browserHistory } from 'react-router';
import { routeCodes } from '../../common/routeConfig';
import '../../../node_modules/bootstrap/scss/bootstrap.scss';
import './Login.scss';
import iconLogin from '../../images/lifebank-logo.png';

export default class Login extends React.Component {

  validateUser() {
    let user = document.getElementById('username').value;
    let pass = document.getElementById('password').value;

    if (user === 'lifebank' && pass === 'test') {
      browserHistory.push(routeCodes.WELCOME_SIGN);
    }

  }

  render() {

    return (
      <div>
        <div className='wrapperLogin'>
        </div>
          <div class="jumbotron" style={{ marginBottom: 0 }}>
            <div style={{ textAlign: 'center' }}>
              <h2 class="display-4">Iniciar sesión</h2>
            </div>

            <div style={{ textAlign: 'center' }}>
              <img className="card-img-top" src={iconLogin} alt="Imagen" style={{ height: 50 + 'px', width: 'auto' }} />
            </div>

            <form>
              <div className="row offset-md-4">
                <div className="col-md-6">
                  <div class="form-group">
                    <label htmlFor="userName">Usuario</label>
                    <input type="text" id="username" className="form-control" placeholder="Ingrese su usuario" required />
                  </div>
                </div>
              </div>

              <div className="row offset-md-4">
                <div className="col-md-6">
                  <div class="form-group">
                    <label htmlFor="pass">Contraseña</label>
                    <input type="password" id="password" className="form-control" placeholder="Ingrese su contraseña" required />
                  </div>
                </div>
              </div>
              </form>
              <div className="row offset-md-4">
                <div className="col-md-6">
                  <div class="form-group">
                    <button className="btn btn-primary" style={{ marginRight: '1rem' }} onClick={() => { this.validateUser() }}>Iniciar sesión</button>
                    <a class="btn btn-danger" href='/reset-pass'>Olvide mi contraseña</a>
                  </div>
                </div>
              </div>
            
          </div>
          <div className='wrapperLogin'>
        </div>
        </div>
    );
  }
}

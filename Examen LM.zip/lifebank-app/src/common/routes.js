import React, { Component } from 'react';
import { Router, Route, IndexRoute, browserHistory } from 'react-router';
/** importing views */
import App from '../views/App/App';
import Welcome from '../views/Welcome/Welcome';
import Login from '../views/Login/Login';
import WelcomeSigned from '../views/Welcome/WelcomeSigned';
/** views for accounts */
import Account from '../views/Account/Account';
import OwnTransfer from '../views/Transfer/OwnTransfer';
import ThirdTransfer from '../views/Transfer/ThirdTransfer';
/** views for loans */
import Loan from '../views/Loan/Loan';
import OwnLoan from '../views/Loan/OwnLoan';
import ThirdLoan from '../views/Loan/ThirdLoan';
/** views for cards */
import Card from '../views/Card/Card';
import OwnCard from '../views/Card/OwnCard';
import ThirdCard from '../views/Card/ThirdCard';
/** views for recipients */
import AddUser from '../views/User/AddUser';
import User from '../views/User/User';
import ChangeUser from '../views/User/ChangeUser';
/** others */
import NotFound from '../views/NotFound/NotFound';
import ResetPassword from '../views/Password/ResetPassword';
import ChangePassword from '../views/Password/ChangePassword';


export default class Routes extends Component {
  render() {
    return (
      <Router history={browserHistory}>
        <div>
          <Route path="/" component={App} >
            <IndexRoute path="/" component={Welcome} />
            
            <Route path="/login" component={Login} />
            <Route path="/welcome-sign" component={WelcomeSigned} />

            <Route path="/account" component={Account} />
            <Route path="/own-transfer" component={OwnTransfer} />
            <Route path="/third-transfer" component={ThirdTransfer} />
            <Route path="/loan" component={Loan} />
            <Route path="/own-loan" component={OwnLoan} />
            <Route path="/third-loan" component={ThirdLoan} />
            <Route path="/card" component={Card} />
            <Route path="/own-card" component={OwnCard} />
            <Route path="/third-card" component={ThirdCard} />

            <Route path="/user" component={User} />
            <Route path="/add-user" component={AddUser} />
            <Route path="/change-user" component={ChangeUser} />
            <Route path="/reset-pass" component={ResetPassword} />
            <Route path="/change-pass" component={ChangePassword} />
            <Route path='*' component={ NotFound } />
          </Route>
        </div>
      </Router>
    );
  }
}

import BaseValidator from './base';

import UserModel from '../models/User';

class UserValidator extends BaseValidator {

  validateUserResponse(data) {
    return this.validate(UserModel, data);
  }
}

export default UserValidator;

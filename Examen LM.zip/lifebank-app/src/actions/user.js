import api from '../api/user';
import userTransformer from '../transformers/user';
//import {NOT_SESSION_ERROR,GENERAL_ERROR} from 'common/constants';

export const GET_USER_ACTION_START = 'GET_USER_ACTION_START';
export const GET_USER_ACTION_ERROR = 'GET_USER_ACTION_ERROR';
export const GET_USER_ACTION_SUCCESS = 'GET_USER_ACTION_SUCCESS';

export const TRANSFORMATION_ERROR = {
  message: 'Data transformation failed - data does not conform to validators.',
};

function getUserActionStart() {
  return {
    type: GET_USER_ACTION_START,
  };
}

function getUserActionError(error) {
  return {
    type: GET_USER_ACTION_ERROR,
    error,
  };
}

function getUserActionSuccess(data) {
  return {
    type: GET_USER_ACTION_SUCCESS,
    data,
  };
}

export function getUsersAsync() {
  return function (dispatch) {
    dispatch(getUserActionStart());
    api.getUsersAsync()
    .then(data => dispatch(() => {
      const trasformedData = userTransformer.transformUserResponse(data);
      if (trasformedData) {
        dispatch(getUserActionSuccess(trasformedData));
      } else {
        dispatch(getUserActionError(TRANSFORMATION_ERROR));
      }
    }))
    .catch(error => dispatch(getUserActionError(error)));
    /*.then(response => {
      const statusReq = response.status;
      if(statusReq == 200 || statusReq == 202) {
        return response.json();
      }
      else {
        if (statusReq == 401 || statusReq == 403) {
          dispatch(getAboutLifemilesActionError(NOT_SESSION_ERROR));
          return false;
        }
        else {
          dispatch(getAboutLifemilesActionError(GENERAL_ERROR));
          return false;
        }
      }
    })*/
      
  };
}

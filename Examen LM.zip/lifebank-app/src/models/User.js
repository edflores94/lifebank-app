/**
 * Model for the users for LifeBank.
 */
const UserModel = {
  beneficiarios: {
    type: 'object',
    optional: false,
    isArray: true,
    item: {
      type: 'object',
      optional: false,
      properties: {
        nombre: {
          type: 'string',
          optional: false,
        },
        numProducto: {
          type: 'string',
          optional: false,
        },
        servicio: {
          type: 'string',
          optional: false,
        },
        correo: {
          type: 'string',
          optional: true,
        }
      }
    }
  }
};

export default UserModel;

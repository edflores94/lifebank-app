import React from 'react';
import {
  Collapse,
  Navbar,
  NavbarToggler,
  NavbarBrand,
  Nav,
  NavItem,
  NavLink,
  UncontrolledDropdown,
  DropdownToggle,
  DropdownMenu,
  DropdownItem
} from 'reactstrap';
import { browserHistory } from 'react-router';
import { routeCodes } from '../../common/routeConfig';
//import iconLB from '../../images/lb-bank.png';

export default class MenuSigned extends React.Component {
  constructor(props) {
    super(props);

    this.toggle = this.toggle.bind(this);
    this.state = {
      isOpen: false
    };
  }

  toggle() {
    this.setState({
      isOpen: !this.state.isOpen
    });
  }

  render() {
    return (
      <div>
        <Navbar color="primary" dark expand="md">
          <NavbarBrand href="/welcome-sign">
            LifeBank
          </NavbarBrand>
          <NavbarToggler onClick={this.toggle} />
          <Collapse isOpen={this.state.isOpen} navbar>
            <Nav className="ml-auto" navbar>

              <UncontrolledDropdown nav inNavbar>
                <DropdownToggle nav caret>
                  Cuentas
                </DropdownToggle>
                <DropdownMenu right>
                  <DropdownItem href="/account">
                    Consultar cuentas
                  </DropdownItem>
                  <DropdownItem href="/own-transfer">
                    Transferencias propias
                  </DropdownItem>
                  <DropdownItem href="/third-transfer">
                    Transferencias a terceros
                  </DropdownItem>
                </DropdownMenu>
              </UncontrolledDropdown>

              <UncontrolledDropdown nav inNavbar>
                <DropdownToggle nav caret>
                  Préstamos
                </DropdownToggle>
                <DropdownMenu right>
                  <DropdownItem href="/loan">
                    Consultar préstamos
                  </DropdownItem>
                  <DropdownItem href="/own-loan">
                    Pago préstamos propios
                  </DropdownItem>
                  <DropdownItem href="/third-loan">
                    Pago préstamos a terceros
                  </DropdownItem>
                </DropdownMenu>
              </UncontrolledDropdown>

              <UncontrolledDropdown nav inNavbar>
                <DropdownToggle nav caret>
                  Tarjetas
                </DropdownToggle>
                <DropdownMenu right>
                  <DropdownItem href="/card">
                    Consultar tarjetas
                  </DropdownItem>
                  <DropdownItem href="/own-card">
                    Pago tarjetas propios
                  </DropdownItem>
                  <DropdownItem href="/third-card">
                    Pago tarjetas a terceros
                  </DropdownItem>
                </DropdownMenu>
              </UncontrolledDropdown>

              <UncontrolledDropdown nav inNavbar>
                <DropdownToggle nav caret>
                  Beneficiarios
                </DropdownToggle>
                <DropdownMenu right>
                  <DropdownItem href="/user">
                    Consultar beneficiaros
                  </DropdownItem>
                  <DropdownItem href="/add-user">
                    Agregar beneficiarios
                  </DropdownItem>
                </DropdownMenu>
              </UncontrolledDropdown>

              <UncontrolledDropdown nav inNavbar>
                <DropdownToggle nav caret>
                  Perfil
                </DropdownToggle>
                <DropdownMenu right>
                  <DropdownItem href='/change-pass'>
                    Cambiar contraseña
                  </DropdownItem>
                  <DropdownItem href='/change-user'>
                    Cambiar usuario
                  </DropdownItem>
                </DropdownMenu>
              </UncontrolledDropdown>

              <NavItem>
                <a class="btn btn-dark" href='/'>Cerrar sesión</a>
              </NavItem>

            </Nav>
          </Collapse>
        </Navbar>
      </div>
    );
  }
}

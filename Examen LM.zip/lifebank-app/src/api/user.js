//import 'es6-promise';
//import 'whatwg-fetch';

function getUsersAsync() {
  //const url = `${ endpoints['users'] }`;
  const url = 'http://private-12729-proyect1.apiary-mock.com/lifebank/users';
debugger;
  return fetch( url)
    .then((response) => {
      return response;
    });
}

export default {
  getUsersAsync,
};

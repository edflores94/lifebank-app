import UserValidator from '../validators/user';

const userValidator = new UserValidator();

const userTransformer = {
  transformUserResponse: (data) => {
    const response = data;
    return userValidator.validateUserResponse(response) ?
      response : null;
  },
};

export default userTransformer;

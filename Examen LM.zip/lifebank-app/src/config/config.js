const endpoints = {
  'generalError': 'https://private-4c4f50-homepage9.apiary-mock.com/error/general',
  'users':'http://private-12729-proyect1.apiary-mock.com/lifebank/users',
};

const envHost = 'http://localhost:47825/';

const if1Pw3 = "44qOoVTcE3jtu/JuzdGRMqg5vQRqL8r5YX6gZD4UDq+5PTgmew1AlVuCuAHEx/MGMuDCx0lvjgjS6pjar9pKj8TYHjxEpvJ/xtC41OwjV6aSeBggux8nkhu/+oGuZZIi0saNN2/VIyqlAzUtKudKJxMvVet4DfXOfx7ub29CHWU=";
import { Map } from 'immutable';

import {
  GET_USER_ACTION_START,
  GET_USER_ACTION_ERROR,
  GET_USER_ACTION_SUCCESS,
} from 'actions/user';

const initialState = Map({
  users: {},
});

const actionsMap = {
  [GET_USER_ACTION_START]: (state) => {
    return state.merge({
      users:  {
        asyncLoading: true,
        asyncError: null,  
      }
    });
  },
  [GET_USER_ACTION_ERROR]: (state, action) => {
    return state.merge(Map({
      users:  {
        asyncLoading: false,
        asyncError: action.error,    
      }
    }));
  },
  [GET_USER_ACTION_SUCCESS]: (state, action) => {
    return state.merge(Map({
      asyncLoading: false,
      users: action.data,
    }));
  },
};

export default function reducer(state = initialState, action = {}) {
  const fn = actionsMap[action.type];
  return fn ? fn(state, action) : state;
}
